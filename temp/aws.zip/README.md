# aws-zabbix-cloudwatch

Cloudwatch integration for Zabbix

## Prerequisites

- Centos 7 or above
- Pyhton 3.6.8, 3.7.4 or 3.8.1
- Installed pip3
- Place the scripts in the same server thats has the zabbix proxy
- Modules: 'boto3', 'argparse', 'configparser'
- User account in AWS and grant it permissions for required services and API calls.

### Configuring aws.conf

Step 1: mkdir -p /usr/lib/zabbix/externalscripts/conf

Step 2: cd /usr/lib/zabbix/externalscripts/conf

Step 3: place the file 'aws_sample.conf'

Step 4: mv aws*sample.conf aws*[client name].conf

    Attention! The client name must be the same inputed into the macro zabbix

Step 5: fill the user variables 'key' and 'secret' with the users

### Configure the scripts

Step 1: cd /usr/lib/zabbix/externalscripts

Step 2: place the files inside the discovery folder

Step 3: chmod +x \*.py

## Execution

Error dictionary:

| Code Number |                      Description                       |
| :---------: | :----------------------------------------------------: |
|     -1      |           Erro com a execução do script rds            |
|     -2      |             Erro na execução do script eks             |
|     -3      |           Erro na execução do script aurora            |
|     -4      | Erro na execução do script vpn site to site connection |
|     -5      |     Erro na execução do script auto scaling group      |
|     -6      |        Erro na execução do script auto dynamodb        |
|     -7      |             Erro na execução do script ecs             |
|     -8      |             Erro na execução do script s3              |
|     -9      |         Erro na execução do script cloudfront          |
|     -10     |             Erro na execução do script elb             |
|     -11     |          Erro na execução do script workspace          |
|     -12     |         Erro na execução do script nat gateway         |
|     -13     |             Erro na execução do script ebs             |
|     -14     |           Erro na execução do script route53           |
|     -15     |             Erro na execução do script efs             |
|     -16     |    Erro na execução do script elasticache memcache     |
|     -17     |    Erro na execução do script elasticache for redis    |
|     -18     |       Erro na execução do script shield advanced       |
|     -19     |             Erro na execução do script waf             |
|     -20     |             Erro na execução do script kms             |
|     -21     |           Erro na execução do script cognito           |
|     -22     |       Erro na execução do script storage gateway       |
|     -23     |          Erro na execução do script redshift           |
|     -24     |      Erro na execução do script de direct connect      |
|     -25     |             Erro na execução do script dms             |
|     -26     |         Erro na execução do script document db         |

### RDS

#### Required variables

- region
- client-name
- metric-name:

|     Metric Name     |  Unit   |        Aggregation        |                                          Description                                          |
| :-----------------: | :-----: | :-----------------------: | :-------------------------------------------------------------------------------------------: |
|   CPUUtilization    | Percent | Average, Maximum, Minimum |                               The percentage of CPU utilization                               |
|    WriteLatency     | Seconds | Average, Maximum, Minimum |                    The average amount of time taken per disk I/O operation                    |
|     ReadLatency     | Seconds | Average, Maximum, Minimum |                    The average amount of time taken per disk I/O operation                    |
|  FreeStorageSpace   |  Bytes  | Average, Maximum, Minimum |                             The amount of available storage space                             |
|   FreeableMemory    |  Bytes  | Average, Maximum, Minimum |                         The amount of available random access memory                          |
|      SwapUsage      |  Bytes  | Average, Maximum, Minimum | The amount of swap space used on the DB instance. This metric is not available for SQL Server |
| DatabaseConnections |  Count  | Average, Maximum, Minimum |                           The number of database connections in use                           |
|  AllocatedStorage   |  Bytes  | Average, Maximum, Minimum |                          The maximum storage allocated for instance                           |

<br/>

- statistics ('Average', 'Maximum', 'Minimum')
- sys-id
  <br/>

To execute the script:

    ./aws_rds.py --region "[region]" --client-name "[client name]" --metric-name "[metric]" --sys-id "[sys id]" --statistic "[statistics]"

    Example:

    ./aws_rds.py --region "sa-east-1" --client-name "sodexo" --metric-name "CPUUtilization" --sys-id "123456789" --statistic "Maximum"

### EKS

#### Required variables

- region
- client-name
- metric-name:

|            Metric Name            |  Unit   |        Aggregation        |                                Description                                |
| :-------------------------------: | :-----: | :-----------------------: | :-----------------------------------------------------------------------: |
|     cluster_failed_node_count     | Number  | Average, Maximum, Minimum |             The number of failed worker nodes in the cluster              |
|        cluster_node_count         | Number  | Average, Maximum, Minimum |              The total number of worker nodes in the cluster              |
|       node_cpu_usage_total        | Number  | Average, Maximum, Minimum |      The number of CPU units being used on the nodes in the cluster       |
|       node_cpu_utilization        | Percent | Average, Maximum, Minimum | The total percentage of CPU units being used on the nodes in the cluster  |
|   node_memory_reserved_capacity   | Percent | Average, Maximum, Minimum | The percentage of memory currently being used on the nodes in the cluster |
|      node_memory_utilization      | Percent | Average, Maximum, Minimum |    The percentage of memory currently being used by the node or nodes     |
|    node_number_of_running_pods    | Number  |          Average          |             The number of running pods per node in a cluster              |
| node_number_of_running_containers | Number  |          Average          |          The number of running containers per node in a cluster           |
|        pod_cpu_utilization        | Percent |          Average          |              The percentage of CPU units being used by pods               |
|      pod_memory_utilization       | Percent |          Average          |     The percentage of memory currently being used by the pod or pods      |

<br/>

- statistics ('Average', 'Maximum', 'Minimum')
- sys-id
  <br/>

#### Optional variables

- node name
- instance ID
- pod Name
- service
- namespace

To execute the script:

    ./aws_eks.py --region "[region]" --client-name "[client name] --metricname "[metric]" --stat "[statistics]" --clusterName "[cluster name]"

    Examples:

    ./aws_eks.py --region "sa-east-1" --client-name "sodexo" --metricname "node_cpu_utilization" --stat "Maximum" --clusterName "eks_cluster_pcms"

    ./aws_eks.py --region "sa-east-1" --client-name "sodexo" --metricname "node_cpu_utilization" --stat "Maximum" --clusterName "eks_cluster_pcms" --instanceID "i-041d3796ab90818f8" --nodeName "ip-10-0-111-164.sa-east-1.compute.internal"

### AURORA

#### Required variables

##### aws_aurora_instances.py

- region
- client-name
- sys-id

##### aws_aurora_cluster.py

- region
- client-name
- metric-name:

|     Metric Name     |       Unit       |        Aggregation        |                                         Description                                         |
| :-----------------: | :--------------: | :-----------------------: | :-----------------------------------------------------------------------------------------: |
|  AuroraReplicaLag   |   Milliseconds   | Average, Maximum, Minimum | For an Aurora replica, the amount of lag when replicating updates from the primary instance |
|   CPUUtilization    |    Percentage    | Average, Maximum, Minimum |                     The percentage of CPU used by an Aurora DB instance                     |
| DatabaseConnections |      Count       | Average, Maximum, Minimum |                     The number of connections to an Aurora DB instance                      |
|  FreeLocalStorage   |      Bytes       | Average, Maximum, Minimum |                            The amount of local storage available                            |
|   FreeableMemory    |      Bytes       | Average, Maximum, Minimum |                        The amount of available random access memory                         |
|      SwapUsage      |      Bytes       | Average, Maximum, Minimum |                                The amount of swap space used                                |
|    InsertLatency    |   Milliseconds   | Average, Maximum, Minimum |                               The latency for insert queries                                |
|       Queries       | Count per second | Average, Maximum, Minimum |                      The average number of queries executed per second                      |

<br/>

- statistics ('Average', 'Maximum', 'Minimum')
- sys-id

##### Execution aws_aurora_instances.py

This script list the databases instances.

To execute the script:

    ./aws_aurora_instances.py --region "[region]" --client-name "[client name]  --sys-id "[sys id]"

    Example:

    ./aws_aurora_instances.py --region "sa-east-1" --client-name "sodexo"  --sys-id "1234567"

##### Execution aws_aurora_cluster.py

To execute the script:

    ./aws_aurora_cluster.py --region "[region]" --client-name "[client name]  --metric-name "[metric]" --sys-id "[sys id]" --statistic "[statistics]"

    Example:

    ./aws_aurora_cluster.py --region "sa-east-1" --client-name "sodexo" --metric-name "CPUUtilization"  --sys-id "1234567" --statistic "Average"

**IMPORTANT**: to get instances metrics use the aws_rds.py script

## VPN Site to Site Connection

#### Required variables

##### aws_vpn_s2s_discovery.py

- region
- client-name
- sys-id

##### aws_vpn_s2s.py

- region
- client-name
- metric-name:

|  Metric Name  |  Unit  |        Aggregation        |                                                                       Description                                                                       |
| :-----------: | :----: | :-----------------------: | :-----------------------------------------------------------------------------------------------------------------------------------------------------: |
|  TunnelState  | Number | Average, Maximum, Minimum | The state of the tunnel. For static VPNs, 0 indicates DOWN and 1 indicates UP. For BGP VPNs, 1 indicates ESTABLISHED and 0 is used for all other states |
| TunnelDataIn  | Bytes  | Average, Maximum, Minimum |                                       The bytes received on the AWS side of the connection through the VPN tunnel                                       |
| TunnelDataOut | Bytes  | Average, Maximum, Minimum |                                        The bytes sent from the AWS side of the connection through the VPN tunnel                                        |

<br/>

- statistics ('Average', 'Maximum', 'Minimum')
- tunnel-ip-address
- vpn-id

##### Execution aws_vpn_s2s_discovery.py

This script list the tunnels of a specific vpn.

To execute the script:

    ./aws_vpn_s2s_discovery.py --region "[region]" --client-name "[client name]  --sys-id "[sys id]"

    Example:

    ./aws_vpn_s2s_discovery.py --region "sa-east-1" --client-name "sodexo"  --sys-id "1234567"

##### Execution aws_vpn_s2s.py

To execute the script:

    ./aws_vpn_s2s.py --region "[region]" --client-name "[client name] --metric-name "[metric]" --statistic "[statistics]"  --tunnel-ip-address "[tunnel ip address]" --vpn-id "[vpn id]"

    Example:

    ./aws_vpn_s2s.py --region "sa-east-1" --client-name "sodexo" --metric-name "TunnelState" --statistic "Average" --tunnel-ip-address "192.192.66.66" --vpn-id "vpn-1234"

## Auto Scaling Group

#### Required variables

##### aws_auto_scaling_group_discovery.py

- region
- client-name
- sys-id
- kind ('group', 'instance')

##### aws_auto_scaling_group.py

- region
- client-name
- metric-name:

|  Namespace  |        Metric Name        |    Unit    |        Aggregation        |                                                              Description                                                               |
| :---------: | :-----------------------: | :--------: | :-----------------------: | :------------------------------------------------------------------------------------------------------------------------------------: |
| AutoScaling |    GroupTotalInstances    |   Number   | Average, Maximum, Minimum |                                        The total number of instances in the Auto Scaling group.                                        |
| AutoScaling |   GroupPendingInstances   |   Number   | Average, Maximum, Minimum |                          The number of instances that are pending. A pending instance is not yet in service.                           |
| AutoScaling | GroupTerminatingInstances |   Number   | Average, Maximum, Minimum | The number of instances that are in the process of terminating. This metric does not include instances that are in service or pending. |
|     EC2     |      CPUUtilization       | Percentage | Average, Maximum, Minimum |                        The percentage of allocated EC2 compute units that are currently in use on the instance.                        |
|     EC2     |     StatusCheckFailed     |   Count    | Average, Maximum, Minimum |         Reports whether the instance has passed both the instance status check and the system status check in the last minute.         |

<br/>

- statistics ('Average', 'Maximum', 'Minimum')
- auto-scaling-group
- instance-id

##### Execution aws_auto_scaling_group_discovery.py

This script list the tunnels of a specific vpn.

To execute the script:

    ./aws_auto_scaling_group_discovery.py --region "[region]" --client-name "[client name]  --sys-id "[sys id]" --kind "[kind]"

    Example:

    ./aws_auto_scaling_group_discovery.py --region "sa-east-1" --client-name "sodexo"  --sys-id "1234567" --kind "group"

##### Execution aws_auto_scaling_group.py

To execute the script:

    ./aws_auto_scaling_group.py --region "[region]" --client-name "[client name] --metric-name "[metric]" --statistic "[statistics]"  --auto-scaling-group "[auto scaling group name]"

    ./aws_auto_scaling_group.py --region "[region]" --client-name "[client name] --metric-name "[metric]" --statistic "[statistics]"  --instance-id "[instance id]"

    Example:

    ./aws_auto_scaling_group.py --region "sa-east-1" --client-name "sodexo" --metric-name "GroupPendingInstances" --statistic "Average" --auto-scaling-group "PCMS-MSH-GROUP"

    ./aws_auto_scaling_group.py --region "sa-east-1" --client-name "sodexo" --metric-name "CPUUtilization" --statistic "Average" --instance-id "i-00000000000000"

## DynamoDB

#### Required variables

##### aws_dynamodb.py

- region
- client-name
- sys-id
- metric-name:

|          Metric Name          |    Unit    |        Aggregation        |                                                                                                                                            Description                                                                                                                                            |
| :---------------------------: | :--------: | :-----------------------: | :-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------: |
| ProvisionedReadCapacityUnits  |   Number   | Average, Maximum, Minimum |                                                                                                      The number of provisioned read capacity units for a table or a global secondary index.                                                                                                       |
| ProvisionedWriteCapacityUnits |   Number   | Average, Maximum, Minimum |                                                                                                      The number of provisioned write capacity units for a table or a global secondary index.                                                                                                      |
|   ConsumedReadCapacityUnits   |   Number   | Average, Maximum, Minimum |  The number of read capacity units consumed over the specified time period, so you can track how much of your provisioned throughput is used. You can retrieve the total consumed read capacity for a table and all of its global secondary indexes, or for a particular global secondary index.  |
|  ConsumedWriteCapacityUnits   | Percentage | Average, Maximum, Minimum | The number of write capacity units consumed over the specified time period, so you can track how much of your provisioned throughput is used. You can retrieve the total consumed write capacity for a table and all of its global secondary indexes, or for a particular global secondary index. |

<br/>

- statistics ('Average', 'Maximum', 'Minimum')

##### Execution aws_dynamodb.py

To execute the script:

    ./aws_dynamodb.py --region "[region]" --client-name "[client name] --metric-name "[metric]" --statistic "[statistics]" --sys-id "[sys-id]"

    Example:

    ./aws_dynamodb.py --region "sa-east-1" --client-name "sodexo" --metric-name "ProvisionedReadCapacityUnits" --statistic "Average" --sys-id "1234"

## ECS

#### Required variables

##### aws_ecs.py

- region
- client-name
- sys-id
- metric-name:

|    Metric Name    |    Unit    |        Aggregation        |                                                  Description                                                   |
| :---------------: | :--------: | :-----------------------: | :------------------------------------------------------------------------------------------------------------: |
|  CPUUtilization   |   Number   | Average, Maximum, Minimum |     The CPU units used by tasks in the resource that is specified by the dimension set that you're using.      |
|  CPUReservation   |   Number   | Average, Maximum, Minimum |   The CPU units reserved by tasks in the resource that is specified by the dimension set that you're using.    |
| MemoryUtilization |   Number   | Average, Maximum, Minimum |    The memory being used by tasks in the resource that is specified by the dimension set that you're using.    |
| MemoryReservation | Percentage | Average, Maximum, Minimum | The memory that is reserved by tasks in the resource that is specified by the dimension set that you're using. |

<br/>

- statistics ('Average', 'Maximum', 'Minimum')

##### Execution aws_ecs.py

To execute the script:

    ./aws_ecs.py --region "[region]" --client-name "[client name] --metric-name "[metric]" --statistic "[statistics]" --sys-id "[sys-id]"

    Example:

    ./aws_ecs.py --region "sa-east-1" --client-name "sodexo" --metric-name "MemoryUtilization" --statistic "Average" --sys-id "1234"

## S3

#### Required variables

##### aws_s3.py

- region
- client-name
- sys-id
- metric-name:

|   Metric Name   |  Unit  | Aggregation |                                                                                                                                                                                                                                                 Description                                                                                                                                                                                                                                                 |
| :-------------: | :----: | :---------: | :---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------: |
| BucketSizeBytes | Number |   Average   | A quantidade de dados em bytes armazenados em um bucket nas classes de armazenamento STANDARD, INTELLIGENT_TIERING, Standard-Infrequent Access (STANDARD_IA), OneZone-Infrequent Access (ONEZONE_IA), Reduced Redundancy Storage (RRS), Deep Archive Storage (S3 Glacier Deep Archive) ou Glacier (GLACIER). O valor é calculado somando o tamanho de todos os objetos do bucket (objetos atuais e não atuais), incluindo o tamanho de todas as partes de todos os multipart uploads incompletos do bucket. |

<br/>

- statistics ('Average', 'Maximum', 'Minimum')

##### Execution aws_s3.py

To execute the script:

    ./aws_s3.py --region "[region]" --client-name "[client name] --metric-name "[metric]" --statistic "[statistics]" --sys-id "[sys-id]"

    Example:

    ./aws_s3.py --region "sa-east-1" --client-name "sodexo" --metric-name "BucketSizeBytes" --statistic "Average" --sys-id "1234"

## CloudFront

#### Required variables

##### aws_cloudfront.py

- region
- client-name
- sys-id
- metric-name:

|  Metric Name   |  Unit  | Aggregation |                                          Description                                           |
| :------------: | :----: | :---------: | :--------------------------------------------------------------------------------------------: |
| 4xxxErrorRate  | Number |   Average   |    The percentage of all viewer requests for which the response’s HTTP status code is 4xx.     |
|  5xxErrorRate  | Number |   Average   |    The percentage of all viewer requests for which the response’s HTTP status code is 5xx.     |
| TotalErrorRate | Number |   Average   | The percentage of all viewer requests for which the response’s HTTP status code is 4xx or 5xx. |

<br/>

- statistics ('Average', 'Maximum', 'Minimum')

##### Execution aws_cloudfront.py

To execute the script:

    ./aws_cloudfront.py --region "[region]" --client-name "[client name] --metric-name "[metric]" --statistic "[statistics]" --sys-id "[sys-id]"

    Example:

    ./aws_cloudfront.py --region "us-east-1" --client-name "sodexo" --metric-name "4xxxErrorRate" --statistic "Average" --sys-id "1234"

P.S.: It's only possible gathering the information from CloudFront by Cloudwatch metrics when is configured "US East (N. Virginia) Region (us-east-1)", as already changed on sample above.

## ELASTIC LOAD BALANCER

#### Required variables

##### aws_elb.py

- region
- client-name
- sys-id
- metric-name:

|    Metric Name     | Unit  |          Aggregation          |                                                                         Description                                                                         |
| :----------------: | :---: | :---------------------------: | :---------------------------------------------------------------------------------------------------------------------------------------------------------: |
|    RequestCount    | Count |              Sum              | The number of requests processed over IPv4 and IPv6. This metric is only incremented for requests where the load balancer node was able to choose a target. |
|  HealthyHostCount  | Count |   Average, Minimum, Maximum   |                                                     The number of targets that are considered healthy.                                                      |
| TargetResponseTime | Count |            Average            |                   The time elapsed, in seconds, after the request leaves the load balancer until a response from the target is received.                    |
| UnHealthyHostCount | Count | Average, Minimum, and Maximum |                                                    The number of targets that are considered unhealthy.                                                     |

<br/>

- statistics ('Average', 'Maximum', 'Minimum','Sum')

##### Execution aws_elb.py

To execute the script:

    ./aws_elb.py --region "[region]" --client-name "[client name] --metric-name "[metric]" --statistic "[statistics]" --sys-id "[sys-id]"

    Example:

    ./aws_elb.py --region "sa-east-1" --client-name "sodexo" --metric-name "RequestCount" --statistic "Sum" --sys-id "1234"

## WORKSPACES

#### Required variables

##### aws_workspace.py

- region
- client-name
- sys-id
- metric-name:

|    Metric Name    |    Unit     |        Dimension         |                 Aggregation                 |                                         Description                                          |
| :---------------: | :---------: | :----------------------: | :-----------------------------------------: | :------------------------------------------------------------------------------------------: |
|     Available     |    Count    | DirectoryId, WorkspaceId | Average, Minimum, Maximum, Sum, SampleCount |                   The number of WorkSpaces that returned a healthy status.                   |
|     Unhealthy     |    Count    | DirectoryId, WorkspaceId | Average, Minimum, Maximum, Sum, SampleCount |                 The number of WorkSpaces that returned an unhealthy status.                  |
|   UserConnected   |    Count    | DirectoryId, WorkspaceId | Average, Minimum, Maximum, Sum, SampleCount |                     The number of WorkSpaces that have a user connected.                     |
|    Maintenance    |    Count    | DirectoryId, WorkspaceId | Average, Minimum, Maximum, Sum, SampleCount |                     The number of WorkSpaces that are under maintenance.                     |
|      Stopped      |    Count    | DirectoryId, WorkspaceId | Average, Minimum, Maximum, Sum, SampleCount |                          The number of WorkSpaces that are stopped.                          |
| ConnectionAttempt |    Count    |       DirectoryId        | Average, Minimum, Maximum, Sum, SampleCount |                              The number of connection attempts.                              |
| ConnectionSuccess |    Count    |       DirectoryId        | Average, Minimum, Maximum, Sum, SampleCount |                            The number of successful connections.                             |
| ConnectionFailure |    Count    |       DirectoryId        | Average, Minimum, Maximum, Sum, SampleCount |                              The number of failed connections.                               |
| SessionLaunchTime |   Second    |       DirectoryId        | Average, Minimum, Maximum, Sum, SampleCount |                The amount of time it takes to initiate a WorkSpaces session.                 |
| InSessionLatency  | Millisecond |       DirectoryId        | Average, Minimum, Maximum, Sum, SampleCount |             The round trip time between the WorkSpaces client and the WorkSpace.             |
| SessionDisconnect |    Count    |       DirectoryId        | Average, Minimum, Maximum, Sum, SampleCount | The number of connections that were closed, including user-initiated and failed connections. |

<br/>

- statistics ('Average', 'Maximum', 'Minimum','Sum','SampleCount')
- dimension ('DirectoryId', 'WorkspaceId')

DirectoryId, WorkspaceId

##### Execution aws_workspace.py

To execute the script:

    ./aws_workspace.py --region "[region]" --client-name "[client name] --metric-name "[metric]" --statistic "[statistics]" --sys-id "[sys-id]" --dimension "[dimension]"

    Example:

    ./aws_workspace.py --region "sa-east-1" --client-name "sodexo" --metric-name "RequestCount" --statistic "Average" --sys-id "1234" --dimension "DirectoryId"

## NAT GATEWAY

#### Required variables

##### aws_nat_gateway.py

- region
- client-name
- sys-id
- metric-name:

|        Metric Name         | Unit  | Aggregation |                                                                                                                                       Description                                                                                                                                        |
| :------------------------: | :---: | :---------: | :--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------: |
|   ActiveConnectionCount    | Count |   Maximum   |                                                          The total number of concurrent active TCP connections through the NAT gateway. A value of zero indicates that there are no active connections through the NAT gateway.                                                          |
|   ConnectionAttemptCount   | Count |     Sum     | The number of connection attempts made through the NAT gateway. If the value for ConnectionEstablishedCount is less than the value for ConnectionAttemptCount, this indicates hat clients behind the NAT gateway attempted to establish new connections for which there was no response. |
| ConnectionEstablishedCount | Count |     Sum     | The number of connections established through the NAT gateway. If the value for ConnectionEstablishedCount is less than the value for ConnectionAttemptCount, this indicates that clients behind the NAT gateway attempted to establish new connections for which there was no response. |
|      PacketsDropCount      | Count |     Sum     |                                          The number of packets dropped by the NAT gateway. A value greater than zero may indicate an ongoing transient issue with the NAT gateway. If this value is high, see the AWS service health dashboard                                           |

<br/>

- statistics ('Maximum', 'Sum')

##### Execution aws_nat_gateway.py

To execute the script:

    ./aws_nat_gateway.py --region "[region]" --client-name "[client name] --metric-name "[metric]" --statistic "[statistics]" --sys-id "[sys-id]"

    Example:

    ./aws_nat_gateway.py --region "sa-east-1" --client-name "sodexo" --metric-name "ActiveConnectionCount" --statistic "Maximum" --sys-id "1234"

## ELASTIC BLOCK STORAGE - EBS

#### Required variables

##### aws_ebs.py

- region
- client-name
- sys-id
- metric-name:

|    Metric Name    | Unit  |        Aggregation        |                                                      Description                                                      |
| :---------------: | :---: | :-----------------------: | :-------------------------------------------------------------------------------------------------------------------: |
|  VolumeReadBytes  | Bytes | Sum, Average, SampleCount |                      Provides information on the read operations in a specified period of time.                       |
| VolumeWriteBytes  | Bytes | Sum, Average, SampleCount |                      Provides information on the write operations in a specified period of time.                      |
|   VolumeReadOps   | Count |          Average          |  The total number of read operations in a specified period of time. Note: read operations are counted on completion.  |
|  VolumeWriteOps   | Count |          Average          | The total number of write operations in a specified period of time. Note: write operations are counted on completion. |
| VolumeQueueLength | Count |          Average          |        The number of read and write operation requests waiting to be completed in a specified period of time.         |

<br/>

- statistics ('Average', 'SampleCount', 'Sum')

##### Execution aws_ebs.py

To execute the script:

    ./aws_ebs.py --region "[region]" --client-name "[client name] --metric-name "[metric]" --statistic "[statistics]" --sys-id "[sys-id]"

    Example:

    ./aws_ebs.py --region "sa-east-1" --client-name "sodexo" --metric-name "VolumeWriteBytes" --statistic "Average" --sys-id "1234"

## Route53

#### Required variables

##### aws_route53.py

- client-name
- sys-id
- metric-name:

|              Metric Name               |  Unit   |   Aggregation    |                                                     Description                                                      |
| :------------------------------------: | :-----: | :--------------: | :------------------------------------------------------------------------------------------------------------------: |
|               DNSQueries               |  Count  | Sum, SampleCount | For all the records in a hosted zone, the number of DNS queries that Route53 responds to in a specified time period. |
|         DNSSECInternalFailure          |  Count  |        -         |         Value is 1 if any object in the hosted zone is in an INTERNAL_FAILURE state. Otherwise, value is 0.          |
|   DNSSECKeySigningKeysNeedingAction    |  Count  | Sum, SampleCount |               Number of key signing keys (KSKs) that have an ACTION_NEEDED state (due to KMS failure).               |
| DNSSECKeySigningKeyMaxNeedingActionAge | Seconds |        -         |                   Time elapsed since the key signing key (KSK) was set to the ACTION_NEEDED state.                   |
|         DNSSECKeySigningKeyAge         | Seconds |        -         |              The time elapsed since the key signing key (KSK) was created (not since it was activated).              |

<br/>

- statistics ('SampleCount', 'Sum')

##### Execution aws_route53.py

To execute the script:

    ./aws_route53.py --client-name "[client name] --metric-name "[metric]" --statistic "[statistics]" --sys-id "[sys-id]"

    Example without aggregation:

    ./aws_route53.py --client-name "sodexo" --metric-name "DNSSECInternalFailure" --sys-id "1234"

    Example with aggregation:

    ./aws_route53.py --client-name "sodexo" --metric-name "DNSQueries" --statistic "Average" --sys-id "1234"

## ELASTIC FILE SYSTEM - EFS

#### Required variables

##### aws_efs.py

- region
- client-name
- sys-id
- metric-name:

|    Metric Name    |     Unit     |                 Aggregation                 |                                                                                                                                                                                                                                                                                                                                                    Description                                                                                                                                                                                                                                                                                                                                                    |
| :---------------: | :----------: | :-----------------------------------------: | :---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------: |
| ClientConnections |    Count     |                     Sum                     |                                                                                                                                                                                                                                                                                     The number of client connections to a file system. When using a standard client, there is one connection per mounted Amazon EC2 instance.                                                                                                                                                                                                                                                                                     |
|  PercentIOLimit   |   Percent    |                   Average                   |                                                                                                                                                                                                                                  Shows how close a file system is to reaching the I/O limit of the General Purpose performance mode. If this metric is at 100 percent more often than not, consider moving your application to a file system using the Max I/O performance mode.                                                                                                                                                                                                                                  |
|   TotalIOBytes    | Bytes, Count | Minimum, Maximum, Average, Sum, SampleCount | The actual number of bytes for each file system operation, including data read, data write, and metadata operations. This is the actual amount that your application is driving, and not the throughput the file system is being metered at. It might be higher than the numbers shown in PermittedThroughput. The Sum statistic is the total number of bytes associated with all file system operations. The Minimum statistic is the size of the smallest operation during the period. The Maximum statistic is the size of the largest operation during the period. The Average statistic is the average size of an operation during the period. The SampleCount statistic provides a count of all operations. |

<br/>

- statistics ('Minimum', 'Maximum', 'Average', 'Sum', 'SampleCount')

##### Execution aws_efs.py

To execute the script:

    ./aws_efs.py --region "[region]" --client-name "[client name] --metric-name "[metric]" --statistic "[statistics]" --sys-id "[sys-id]"

    Example:

    ./aws_efs.py --region "sa-east-1" --client-name "sodexo" --metric-name "ClientConnections" --statistic "Sun" --sys-id "1234"

## Elasticache Memcache

#### Required variables

##### aws_elasticache_memcache.py

- client-name
- sys-id
- metric-name:

|   Metric Name   |  Unit   |          Aggregation          |                                                                         Description                                                                         |
| :-------------: | :-----: | :---------------------------: | :---------------------------------------------------------------------------------------------------------------------------------------------------------: |
| CPUUtilization  | Percent |            Average            |                                                   The percentage of CPU utilization for the entire host.                                                    |
|    SwapUsage    |  Bytes  |            Average            |                                                            The amount of swap used on the host.                                                             |
|    Evictions    |  Count  |            Maximum            |                                      The number of non-expired items the cache evicted to allow space for new writes.                                       |
| CurrConnections |  Count  |              Sum              | A count of the number of connections connected to the cache at an instant in time. ElastiCache uses two to three of the connections to monitor the cluster. |
| FreeableMemory  |  Bytes  | Average, Minimum, and Maximum |             The amount of free memory available on the host. This is derived from the RAM, buffers, and cache that the OS reports as freeable.              |

<br/>

- statistics ('Average', 'Maximum', 'Minimum', 'Sum')

#### Execution aws_elasticache_memcache

To execute the script:

    ./aws_elasticache_memcache.py --client-name "[client name] --sys-id "[sys-id]" --statistic "[statistics]" --metric-name "[metric]"

    Example:

    ./aws_elasticache_memcache.py --client-name "sample" --sys-id "789951357896578" --statistic "Average" --metric-name "CPUUtilization"

## Elasticache For Redis

#### Required variables

##### aws_elasticache_for_redis.py

- client-name
- sys-id
- metric-name:

|          Metric Name          |  Unit   |          Aggregation          |                                                                                                             Description                                                                                                              |
| :---------------------------: | :-----: | :---------------------------: | :----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------: |
| DatabaseMemoryUsagePercentage | Percent |            Average            |                                                                                  Percentage of the memory available for the cluster that is in use.                                                                                  |
|        CPUUtilization         | Percent |            Average            |                            The percentage of CPU utilization for the entire host. Because Redis is single-threaded, we recommend you monitor EngineCPUUtilization metric for nodes with 4 or more vCPUs.                             |
|           SwapUsage           |  Bytes  |            Average            |                                                                                                 The amount of swap used on the host.                                                                                                 |
|           Evictions           |  Count  |            Maximum            |                                                 The number of keys that have been evicted due to the maxmemory limit. This is derived from the evicted_keys statistic at Redis INFO.                                                 |
|        CurrConnections        |  Count  |              Sum              | The number of client connections, excluding connections from read replicas. ElastiCache uses two to four of the connections to monitor the cluster in each case. This is derived from the connected_clients statistic at Redis INFO. |
|        FreeableMemory         |  Bytes  | Average, Minimum, and Maximum |                                                  The amount of free memory available on the host. This is derived from the RAM, buffers, and cache that the OS reports as freeable.                                                  |

<br/>

- statistics ('Average', 'Maximum', 'Minimum', 'Sum')

#### Execution aws_elasticache_for_redis.py

To execute the script:

    ./aws_elasticache_for_redis.py --client-name "[client name] --sys-id "[sys-id]" --statistic "[statistics]" --metric-name "[metric]"

    Example:

    ./aws_elasticache_for_redis.py --client-name "sample" --sys-id "789951357896578" --statistic "Average" --metric-name "DatabaseMemoryUsagePercentage"

## SHIELD ADVANCED

#### Required variables

##### aws_shield.py

- client-name
- sys-id
- metric-name:

|           Metric Name           |   Unit   | Aggregation |                                                                                                                                                Description                                                                                                                                                |
| :-----------------------------: | :------: | :---------: | :-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------: |
|          DDoS Detected          |  0 or 1  |   Average   |                                                                     Indicates whether a DDoS event is underway for a particular Amazon Resource Name (ARN). This metric has a value of 1 during an event and a value of 0 otherwise.                                                                      |
|   DDoS Attack Bits Per Second   |   Bits   |   Average   |                               The number of bits observed during a DDoS event for a particular Amazon Resource Name (ARN). This metric is available only for layer 3 and layer 4 DDoS events. This metric has a non-zero value during an event and a value of 0 otherwise.                                |
| DDoS Attack Packets Per Second  | Packets  |   Average   |                              The number of packets observed during a DDoS event for a particular Amazon Resource Name (ARN). This metric is available only for layer 3 and layer 4 DDoS events. This metric has a non-zero value during an event and a value of 0 otherwise.                              |
| DDoS Attack Requests Per Second | Requests |   Average   | The number of requests observed during a DDoS event for a particular Amazon Resource Name (ARN). This metric is available only for layer 7 DDoS events. The metric is reported only for the most significant layer 7 events. This metric has a non-zero value during an event and a value of 0 otherwise. |

<br/>

- statistics ('Average')

##### Execution aws_shield.py

To execute the script:

    ./aws_shield.py --client-name "[client name] --metric-name "[metric]" --statistic "[statistics]" --sys-id "[sys-id]"

    Example:

    ./aws_shield.py --client-name "sodexo" --metric-name "ClientConnections" --statistic "Sun" --sys-id "1234"

## Web Application Firewall - WAF

#### Required variables

##### aws_waf.py

- region
- client-name
- sys-id
- metric-name:

|   Metric Name   | Unit  | Aggregation |                                                                     Description                                                                     |
| :-------------: | :---: | :---------: | :-------------------------------------------------------------------------------------------------------------------------------------------------: |
| AllowedRequests | Count |     Sum     |                                                         The number of allowed web requests.                                                         |
| BlockedRequests | Count |     Sum     |                                                         The number of blocked web requests.                                                         |
| CountedRequests | Count |     Sum     |                                                         The number of counted web requests.                                                         |
| PassedRequests  | Count |     Sum     | The number of passed requests. This is only used for requests that go through a rule group evaluation without matching any of the rule group rules. |

<br/>

- statistics ('Sum')

##### Execution aws_waf.py

To execute the script:

    ./aws_waf.py --region "[region]" --client-name "[client name] --metric-name "[metric]" --statistic "[statistics]" --sys-id "[sys-id]"

    Example:

    ./aws_waf.py --region "sa-east-1" --client-name "sodexo" --metric-name "ClientConnections" --statistic "Sum" --sys-id "1234"

## KMS

#### Required variables

##### aws_kms.py

- region
- client-name
- sys-id
- statistic
- metric-name:

|            Metric Name            |  Unit   | Aggregation |                                       Description                                       |
| :-------------------------------: | :-----: | :---------: | :-------------------------------------------------------------------------------------: |
| SecondsUntilKeyMaterialExpiration | Seconds |   Minimum   | This metric tracks the number of seconds remaining until imported key material expires. |

<br/>

- statistics ('Minimum')

##### Execution aws_kms.py

To execute the script:

    ./aws_kms.py --region "[AWS region]" --client-name "[client-name]" --metric-name "[metric-name]" --statistic "[statistics]" --sys-id "[sys-id]"

    Example:

    ./aws_kms.py --region "sa-east-1" --client-name "sodexo" --metric-name "SecondsUntilKeyMaterialExpiration" --statistic "Minimum" --sys-id "789951357885278"

## COGNITO

#### Required variables

##### aws_cognito.py

- region
- client-name
- sys-id
- metric-name:

|      Metric Name      |           Unit           |        Aggregation        |                                                            Description                                                             |
| :-------------------: | :----------------------: | :-----------------------: | :--------------------------------------------------------------------------------------------------------------------------------: |
|    SignUpSuccesses    | Percentage, Count, Count | Average, SampleCount, Sum |             Provides the total number of successfull user registration requests made to the Amazon Cognito user pool.              |
|    SignUpThrottles    |          Count           |            Sum            |              Provides the total number of throttled user registration requests made to the Amazon Cognito user pool.               |
|    SignInSuccesses    |          Count           | Average, SampleCount, Sum |             Provides the total number of successful user authentication requests made to the Amazon Cognito user pool.             |
|    SignInThrottles    |          Count           |            Sum            |             Provides the total number of throttled user authentication requests made to the Amazon Cognito user pool.              |
| TokenRefreshSuccesses |          Count           | Sum, Average, SampleCount |             Provides the total number of throttled user authentication requests made to the Amazon Cognito user pool.              |
| TokenRefreshThrottles |          Count           |            Sum            | Provides the total number of throttled requests to refresh an Amazon Cognito token that were made to the Amazon Cognito user pool. |
|  FederationSuccesses  |          Count           | Average, SampleCount, Sum |               Provides the total number of successful identity federation requests to the Amazon Cognito user pool.                |
|  FederationThrottles  |          Count           |            Sum            |                Provides the total number of throttled identity federation requests to the Amazon Cognito user pool.                |

<br/>

- statistics ('Minimum', 'Maximum', 'Average', 'Sum', 'SampleCount')

##### Execution aws_cognito.py

To execute the script:

    ./aws_cognito.py --region "[us-east-1]" --client-name "[client name]" --metric-name "[metric]" --statistic "[statistics]" --sys-id "[sys-id]"

    Example:

    ./aws_cognito.py --region "us-east-1" --client-name "sample" --metric-name "SignUpSuccesses" --statistic "Average" --sys-id "789951357896578"

## Storage Gateway

#### Required variables

##### aws_storage_gateway.py

- region
- client-name
- sys-id
- metric-name:

|   Metric Name   |  Unit   |  Aggregation   |      Dimensions      |                                                                                     Description                                                                                      |
| :-------------: | :-----: | :------------: | :------------------: | :----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------: |
| CacheHitPercent | Percent |    Average     | share-id, gateway-id |                                     Percent of application reads served from the cache. The sample is taken at the end of the reporting period.                                      |
|    CacheUsed    |  Bytes  | Average, Count |      gateway-id      |                             The total number of bytes being used in the gateway's cache storage. The sample is taken at the end of the reporting period.                             |
|  MemTotalBytes  |  Bytes  | Average, Count |          -           |                                                                Amount of RAM provisioned to the gateway VM, in bytes.                                                                |
|  MemUsedBytes   |  Bytes  | Average, Count |          -           |                                                             Amount of RAM currently in use by the gateway VM, in bytes.                                                              |
|  QueuedWrites   |  Bytes  | Average, Count |     --gateway-id     | The number of bytes waiting to be written to AWS, sampled at the end of the reporting period for all volumes in the gateway. These bytes are kept in your gateway's working storage. |
| UserCpuPercent  | Percent | Average, Count |          -           |                                                     Percent of CPU time spent on gateway processing, averaged across all cores.                                                      |

- statistics ('Count','Average')

##### aws_storage_gateway_discovery.py

- region
- client-name
- sys-id
- kind

<br/>

#### Optional variables

##### aws_storage_gateway.py

- share-id
- gateway-id

#### Execution aws_storage_gateway.py

To execute the script:

    ./aws_storage_gateway.py --region "[us-east-1]" --client-name "[client name]" --sys-id "[sys-id]" --metric-name "[metric]" --statistic "[statistics]" --share-id "[share-id]" --gateway-id "[share-id]"

    Example:

    ./aws_storage_gateway.py --region "us-east-1" --client-name "sample" --sys-id "753951286458711" --statistic "Average" --metric-name "CacheHitPercent" --share-id "share-74B4211F"
    ./aws_storage_gateway.py --region "us-east-1" --client-name "sample" --sys-id "789654123578963" --statistic "Average" --metric-name "CacheHitPercent" --gateway-id "sgw-FCFB1495"
    ./aws_storage_gateway.py --region "us-east-1" --client-name "sample" --sys-id "785211111147856" --statistic "Average" --metric-name "MemTotalBytes"

#### Execution aws_storage_gateway_discovery.py

To execute the script:

    ./aws_storage_gateway_discovery.py --region "[us-east-1]" --client-name "[client name]" --sys-id "[sys-id]" --kind "[kind]"

    Example:

    ./aws_storage_gateway_discovery.py --region "us-east-1" --client-name "sample" --sys-id "785201456398524" --kind "ShareId"
    ./aws_storage_gateway_discovery.py --region "us-east-1" --client-name "sample" --sys-id "785211111147856" --kind "GatewayId"

## REDSHIFT

#### Required variables

##### aws_redshift.py

- region
- client-name
- sys-id
- metric-name:

|        Metric Name        |     Unit     |        Aggregation        |        Dimensions         |                                                                   Description                                                                    |
| :-----------------------: | :----------: | :-----------------------: | :-----------------------: | :----------------------------------------------------------------------------------------------------------------------------------------------: |
|     CommitQueueLength     |    Count     | Average, Maximum, Minumum |           None            |                                      The number of transactions waiting to commit at a given point in time.                                      |
|      CPUUtilization       |   Percent    |          Average          |      None or node_id      | The percentage of CPU utilization. For clusters, this metric represents an aggregation of all nodes (leader and compute) CPU utilization values. |
|    DatabaseConnections    |    Count     | Average, Maximum, Minimum |           None            |                                                 The number of database connections to a cluster.                                                 |
|       HealthStatus        | Count (1/0)  | Average, Maximum, Minimum |           None            |                                                       Indicates the health of the cluster.                                                       |
|  PercentageDiskSpaceUsed  |   Percent    |          Average          |           None            |                                                         The percent of disk space used.                                                          |
| QueriesCompletedPerSecond | Count/Second |          Average          |          latency          |                                               The average number of queries completed per second.                                                |
|       QueryDuration       | Microseconds |          Average          |          latency          |                                                 The average amount of time to complete a query.                                                  |
|         ReadIOPS          | Count/Second |          Average          |      None or node_id      |                                              The average number of disk read operations per second.                                              |
|        ReadLatency        |   Seconds    |          Average          |      None or node_id      |                                          The average amount of time taken for disk read I/O operations.                                          |
|         WriteIOPS         | Count/Second |          Average          |      None or node_id      |                                                The average number of write operations per second.                                                |
|       WriteLatency        |   Seconds    |          Average          |      None or node_id      |                                         The average amount of time taken for disk write I/O operations.                                          |
|        StorageUsed        |  Megabytes   |          Average          | database_name+schema_name |                                                   The disk or storage space used by a schema.                                                    |

<br/>

- statistics ('Minimum', 'Maximum', 'Average')

##### aws_redshift.py execution

To execute the script:

    ./aws_redshift.py --region "[region]" --client-name "[client name]" --metric-name "[metric]" --statistic "[statistics]" --sys-id "[sys-id]"

    Example:

    ./aws_redshift.py --region "us-east-1" --client-name "SAMPLE.HOSTNAME" --metric-name "HealthStatus" --statistic "Average" --sys-id "123456789098765"

##### aws_redshift_discovery.py execution and dimensions

To execute the script, use `--dimensions` by typing all dimensions wanted separated by a `+` sign:

    ./aws_redshift_discovery.py --region "[region]" --client-name "[client name]" --sys-id "[sys-id]" --dimensions "[dimension list]"

    Examples:

    ./aws_redshift_discovery.py --region "us-east-1" --client-name "SAMPLE.HOSTNAME" --sys-id "123456789098765" --dimensions node_id

    ./aws_redshift_discovery.py --region "us-east-1" --client-name "SAMPLE.HOSTNAME" --sys-id "123456789098765" --dimensions database_name+schema_name

To use the dimensions in the original script `aws_redshift.py`, use their corresponding flags:

    ./aws_redshift.py --region "[region]" --client-name "[client name]" --metric-name "[metric]" --statistic "[statistics]" --sys-id "[sys-id]" --lantecy "[latency]"

    ./aws_redshift.py --region "us-east-1" --client-name "SAMPLE.HOSTNAME" --metric-name "QueriesCompletedPerSecond" --statistic "Average" --sys-id "123456789098765" --lantecy "long"

    ./aws_redshift.py --region "[region]" --client-name "[client name]" --metric-name "[metric]" --statistic "[statistics]" --sys-id "[sys-id]" --database_name "[dbname]" --schema_name "[schema name]"

    ./aws_redshift.py --region "us-east-1" --client-name "SAMPLE.HOSTNAME" --metric-name "StorageUsed" --statistic "Average" --sys-id "123456789098765" --database_name "develop" --schema_name "test"

Possible flags:

- `--node_id`
- `--latency`
- `--wlmid`
- `--stage`
- `--service_class`
- `--queue_name`
- `--query_priority`
- `--database_name`
- `--schema_name`

## DIRECT CONNECT

#### Required variables

##### aws_direct_connect.py

- region
- client-name
- sys-id
- statistic
- metric-name:

|        Metric Name         |        Unit        | Aggregation |                                  Description                                  |
| :------------------------: | :----------------: | :---------: | :---------------------------------------------------------------------------: |
|      ConnectionState       |      Boolean       |   Average   |        This metric is available for dedicated and hosted connections.         |
| VirtualInterfaceBpsEgress  |  Bits per second   |   Average   |   The bitrate for outbound data from the AWS side of the virtual interface.   |
| VirtualInterfaceBpsIngress |  Bits per second   |   Average   |    The bitrate for inbound data to the AWS side of the virtual interface.     |
| VirtualInterfacePpsEgress  | Packets per second |   Average   | The packet rate for outbound data from the AWS side of the virtual interface. |
| VirtualInterfacePpsIngress | Packets per second |   Average   |  The packet rate for inbound data to the AWS side of the virtual interface.   |

<br/>

- statistics ('Average')

#### aws_direct_connect_discovery.py execution

To execute the script:

    ./aws_direct_connect.py --region "[AWS region]" --client-name "[client-name]" --metric-name "[metric-name]" --statistic "[statistics]" --sys-id "[sys-id]"

    Example:

    ./aws_direct_connect.py --region "sa-east-1" --client-name "sodexo" --metric-name "VirtualInterfaceBpsEgress" --statistic "Average" --sys-id "789951357885278"

#### aws_direct_connect_discovery.py execution and dimensions

To execute the script, use --dimensions by typing all dimensions wanted separated by a + sign:

    ./aws_direct_connect_discovery.py --region "[region]" --client-name "[client name]  --sys-id "[sys id]" --dimensions "[dimension list]"

    Example:

    ./aws_direct_connect_discovery.py --region "sa-east-1" --client-name "sodexo"  --sys-id "1234567" --dimensions optical_lane_number
    ./aws_direct_connect_discovery.py --region "sa-east-1" --client-name "sodexo"  --sys-id "1234567" --dimensions optical_lane_number+virtual_interface_id

To use the dimensions in the original script aws_redshift.py, use their corresponding flags:

    ./aws_direct_connect.py --region "[AWS region]" --client-name "[client-name]" --metric-name "[metric-name]" --statistic "[statistics]" --sys-id "[sys-id]" --optical_lane_number "[dimension]"

    Example:

    ./aws_direct_connect.py --region "sa-east-1" --client-name "sodexo" --metric-name "VirtualInterfaceBpsEgress" --statistic "Average" --sys-id "789951357885278" --optical_lane_number "[value]"

Possible flags:

- `--optical_lane_number`
- `--virtual_interface_id`

## DMS

#### Required variables

##### aws_dms.py

- region
- client-name
- sys-id
- metric-name:

|        Metric Name        |     Unit     |        Aggregation        |                            Dimensions                             |                                                                              Description                                                                               |
| :-----------------------: | :----------: | :-----------------------: | :---------------------------------------------------------------: | :--------------------------------------------------------------------------------------------------------------------------------------------------------------------: |
|     FreeStorageSpace      |    Bytes     | Minimum, Maximum, Average |         instance-identifier, resource-id, instance-class          |                                                                 The amount of available storage space.                                                                 |
|      FreeableMemory       |    Bytes     | Minimum, Maximum, Average |         instance-identifier, resource-id, instance-class          |                                                             The amount of available random access memory.                                                              |
|         WriteIOPS         | Count/Second | Minimum, Maximum, Average |         instance-identifier, resource-id, instance-class          |                                                      The average number of disk write I/O operations per second.                                                       |
|         ReadIOPS          | Count/Second | Minimum, Maximum, Average |         instance-identifier, resource-id, instance-class          |                                                       The average number of disk read I/O operations per second.                                                       |
|      WriteThroughput      | Bytes/Second | Minimum, Maximum, Average |         instance-identifier, resource-id, instance-class          |                                                        The average number of bytes written to disk per second.                                                         |
|      ReadThroughput       | Bytes/Second | Minimum, Maximum, Average |         instance-identifier, resource-id, instance-class          |                                                         The average number of bytes read from disk per second.                                                         |
|       WriteLatency        | Milliseconds | Minimum, Maximum, Average |         instance-identifier, resource-id, instance-class          |                                                   The average amount of time taken per disk I/O (output) operation.                                                    |
|        ReadLatency        | Milliseconds | Minimum, Maximum, Average |         instance-identifier, resource-id, instance-class          |                                                    The average amount of time taken per disk I/O (input) operation.                                                    |
|         SwapUsage         |    Bytes     | Minimum, Maximum, Average | instance-identifier, resource-id, instance-class, task-identifier |                                                       The amount of swap space used on the replication instance.                                                       |
| NetworkTransmitThroughput | Bytes/second | Minimum, Maximum, Average |         instance-identifier, resource-id, instance-class          | The outgoing (Transmit) network traffic on the replication instance, including both customer database traffic and AWS DMS traffic used for monitoring and replication. |

<br/>

- statistics ('Minimum', 'Maximum', 'Average')

##### aws_dms_discovery.py

- client-name
- sys-id
- region
- kind

#### Optional variables

##### aws_dms.py

- instance-identifier
- task-identifier
- resource-id
- instance-class

#### Execution aws_dms.py

To execute the script:

    ./aws_dms.py --region "[us-east-1]" --client-name "[client name]" --sys-id "[sys-id]" --statistic "[statistics]" --metric-name "[metric]"
    ./aws_dms.py --region "[us-east-1]" --client-name "[client name]" --sys-id "[sys-id]" --statistic "[statistics]" --metric-name "[metric]" --instance-identifier "[instance identifier]"
    ./aws_dms.py --region "[us-east-1]" --client-name "[client name]" --sys-id "[sys-id]" --statistic "[statistics]" --metric-name "[metric]" --instance-identifier "[instance identifier]" --task-identifier "[task identifier]"
    ./aws_dms.py --region "[us-east-1]" --client-name "[client name]" --sys-id "[sys-id]" --statistic "[statistics]" --metric-name "[metric]" --resource-id "[resource id]"
    ./aws_dms.py --region "[us-east-1]" --client-name "[client name]" --sys-id "[sys-id]" --statistic "[statistics]" --metric-name "[metric]" --instance-class "[instance class]"

    Example:

    ./aws_dms.py --region "us-east-1" --client-name "sample" --sys-id "852111447785632" --statistic "Average" --metric-name "FreeStorageSpace"
    ./aws_dms.py --region "us-east-1" --client-name "sample" --sys-id "852111447785632" --statistic "Average" --metric-name "FreeStorageSpace" --instance-identifier "replication01"
    ./aws_dms.py --region "us-east-1" --client-name "sample" --sys-id "852111447785632" --statistic "Average" --metric-name "SwapUsage" --instance-identifier "replication01" --task-identifier "ReplicationInstanceMonitor"
    ./aws_dms.py --region "us-east-1" --client-name "sample" --sys-id "852111447785632" --statistic "Average" --metric-name "FreeStorageSpace" --resource-id "453BE3X7TPLSPQNG6SMNKTAD5BT4IOJ3WXUQCJQ"
    ./aws_dms.py --region "us-east-1" --client-name "sample" --sys-id "852111447785632" --statistic "Average" --metric-name "FreeStorageSpace" --instance-class "db.t3.medium"

#### Execution aws_dms_discovery.py

To execute the script:

    ./aws_dms_discovery.py --region "[us-east-1]" --client-name "[client name]" --sys-id "[sys-id]" --kind "[kind]"

    Example:

    ./aws_dms_discovery.py --region "us-east-1" --client-name "sample" --sys-id "852111447785632" --kind "InstanceIdentifier+TaskIdentifier"
    ./aws_dms_discovery.py --region "us-east-1" --client-name "sample" --sys-id "852111447785632" --kind "ResourceId"
    ./aws_dms_discovery.py --region "us-east-1" --client-name "sample" --sys-id "852111447785632" --kind "InstanceIdentifier"
    ./aws_dms_discovery.py --region "us-east-1" --client-name "sample" --sys-id "852111447785632" --kind "InstanceClass"

## DOCUMENT DB

#### Required variables

##### aws_document_db_discovery.py

- sys-id
- region
- client-name
- kind

##### aws_document_db.py

- region
- client-name
- metric-name:

|     Metric Name     |     Unit     |        Aggregation        |                                                                       Description                                                                       |
| :-----------------: | :----------: | :-----------------------: | :-----------------------------------------------------------------------------------------------------------------------------------------------------: | --- |
|   CPUUtilization    |   Percent    |          Average          |                                                       The percentage of CPU used by an instance.                                                        |
|   VolumeBytesUsed   |    Bytes     | Sum, Average, SampleCount |                            The amount of storage used by your cluster in bytes. This value affects the cost of the cluster.                             |     |
|   FreeableMemory    |    Bytes     |          Average          |                                                      The amount of available random access memory                                                       |
|  FreeLocalStorage   |    Bytes     |          Maximum          |                           This metric reports the amount of storage available to each instance for temporary tables and logs.                           |
| DatabaseConnections |    Count     |          Average          |                                 The maximum number of open database connections on an instance in a one-minute period.                                  |
|   VolumeReadIOPS    |    Count     |          Average          |                         The average number of billed read I/O operations from a cluster volume, reported at 5-minute intervals.                         |
|   VolumeWriteIOPS   |    Count     |          Average          |                        The average number of billed write I/O operations from a cluster volume, reported at 5-minute intervals.                         |
|  NetworkThroughput  |    Bytes     |          Average          | The amount of network throughput, in bytes per second, both received from and transmitted to clients by each instance in the Amazon DocumentDB cluster. |
|   ReadThroughput    |    Bytes     |          Average          |                                                 The average number of bytes read from disk per second.                                                  |
|   WriteThroughput   |    Bytes     |          Average          |                                                 The average number of bytes written to disk per second.                                                 |
|     ReadLatency     | Milliseconds |          Average          |                                                The average amount of time taken per disk I/O operation.                                                 |
|    WriteLatency     | Milliseconds |          Average          |                                       The average amount of time, in milliseconds, taken per disk I/O operation.                                        |

<br/>

- statistics ('Average', 'Maximum', 'SampleCount')

### Optional variables

#### aws_document_db.py

- db-instance-identifier
- roles

##### Execution aws_document_db_discovery.py

This script list the tunnels of a specific vpn.

To execute the script:

    ./aws_document_db_discovery.py  --sys-id "[sys-id]" --region "[region]" --client-name "[client name]  --dimensions "[dimension]"

    Example:

    ./aws_document_db_discovery.py --sys-id "1234567" --region "us-east-1" --client-name "sodexo" --dimensions "role"


    ./aws_document_db_discovery.py --sys-id "[sys-id]" --region "[region]" --client-name "[client name] --metric-name "[metric]" --statistic "[statistics]"  --role "[Role]"

    Example:

    ./aws_document_db_discovery.py --sys-id "1234567" --region "us-east-1" --client-name "sodexo" --metric-name "CPUUtilization" --statistic "Average" --role "WRITER"

# Document version

- 0.5.27

[TOP](#aws-zabbix-cloudwatch)
