#!/usr/bin/python3

"""Step to discovery DBClusterIdentifier and DBInstanceIdentifier CI from AWS REST API"""

import datetime
import argparse
import aws_client
import aws_tags
import aws_errors
import aws_base

def parse_arguments():
    """Arguments function"""

    parser = argparse.ArgumentParser(
        description='AWS Metrics Zabbix discovery script')
    parser.add_argument("--region", dest="region",
                        help="AWS region.",
                        required=True, type=str)
    parser.add_argument("--client-name", dest="client_name",
                        help="Represents the name of the client inserted in zabbix macro",
                        required=True, type=str)
    parser.add_argument("--sys-id", dest="sys_id",
                        help="TAG SYSID",
                        required=True, type=str)
    parser.add_argument("--metric-name", dest="metric_name",
                    help="Avaible AWS metric name for ECS - 'CPUUtilization', \
                            'CPUReservation', 'MemoryUtilization', \
                            'MemoryReservation'",
                    required=True, type=str)
    parser.add_argument("--statistic", dest="statistic",
                        help="AWS agregation availables: ['Average', 'Maximum', 'Minimum']",
                        required=True, type=str)
    args = parser.parse_args()

    return args

def ecs_handler(login_cloudwatch,metric_name,ecs_cluster_name,statistic):
    """Function to collect the aurora cluster metrics"""

    response = login_cloudwatch.get_metric_data(
    MetricDataQueries=[
    {
        'Id': 'id',
        'MetricStat': {
        'Metric': {
            'Namespace': "AWS/ECS",
            'MetricName': metric_name,
            'Dimensions': [
                    {
                        "Name": "ClusterName",
                        "Value": ecs_cluster_name
                    }]
        },
        'Period': 600,
        'Stat': statistic,
        }
    }
    ],
    StartTime=(datetime.datetime.now() - datetime.timedelta(seconds=300)).timestamp(),
    EndTime=datetime.datetime.now().timestamp()
    )

    return response

def get_value(ecs_metrics):
    """Parsed the output to get the metric"""
    return round(ecs_metrics['MetricDataResults'][0]['Values'][0])

def main():
    """Main code"""

    try:
        arguments = parse_arguments()

        arguments.client_name = aws_base.extract_client_name(arguments.client_name)
        client = aws_client.login_aws(arguments.region,arguments.client_name,'ecs')
        login_cloudwatch = aws_client.login_aws(arguments.region,arguments.client_name)

        ecs_cluster_name = aws_tags.get_ecs_tag(client, arguments.sys_id)
        ecs_metrics = ecs_handler(login_cloudwatch,
                                    arguments.metric_name,
                                    ecs_cluster_name,
                                    arguments.statistic)

        output = get_value(ecs_metrics)
        print(output)

    except:
        aws_errors.throws('ecs')

if __name__ == '__main__':
    main()
