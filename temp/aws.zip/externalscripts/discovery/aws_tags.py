#!/usr/bin/python3

"""This script collects the tags from the components and check the sys id's"""

import re
import json
from botocore.exceptions import ClientError


def get_tag_rds(client, sys_id):
    """Function to collect the 'DBInstanceIdentifier' of database instance"""

    databases = client.describe_db_instances()

    for database in databases['DBInstances']:
        for tag in database['TagList']:
            if tag.get('Key') == 'SYS_ID' and tag.get('Value') == sys_id:
                output = database['DBInstanceIdentifier']

    return output


def get_tag_aurora(client, sys_id):
    """Function to collect the 'DBClusterIdentifier' of cluster Aurora"""

    desc_db_cluster = client.describe_db_clusters()

    for laco_dbcluster in desc_db_cluster['DBClusters']:
        for laco_tag in laco_dbcluster['TagList']:
            if laco_tag.get('Key') == 'SYS_ID' and laco_tag.get('Value') == sys_id:
                output = laco_dbcluster['DBClusterIdentifier']

    return output


def get_tag_eks(login_eks, sys_id):
    """Function that collects the eks cluster name by tag SYS_ID"""

    get_cluster_on_eks = login_eks.list_clusters()
    eks_cluster_name = get_cluster_on_eks['clusters']

    for cluster_list_eks in eks_cluster_name:
        eks_describe = login_eks.describe_cluster(
            name=cluster_list_eks
        )

        dict_tag = eks_describe['cluster']['tags']

        for key, value in dict_tag.items():
            if key == 'SYS_ID' and value == sys_id:
                cluster_name = eks_describe['cluster']['name']

    return cluster_name


def get_vpngateway_id(login, sys_id):
    """Function that collects the VPN Gateway Id by tag SYS_ID"""

    desc_vpn_conn = login.describe_vpn_connections()

    for laco_vpn_connections in desc_vpn_conn['VpnConnections']:
        for laco_tags in laco_vpn_connections['Tags']:
            if laco_tags.get('Key') == 'SYS_ID' and laco_tags.get('Value') == sys_id:
                vpn_connection_id = laco_vpn_connections['VpnGatewayId']

    return vpn_connection_id


def get_auto_scaling_tag(login, sys_id):
    """Function that collects the Auto scaling group name by tag SYS_ID in describe tags"""

    output_tags = login.describe_tags(
        Filters=[
            {
                'Name': 'Value',
                'Values': [
                    sys_id
                ]
            }
        ]
    )

    for tag in output_tags['Tags']:
        if tag['Key'] == 'SYS_ID' and\
                tag['Value'] == sys_id:
            auto_scaling_name = tag['ResourceId']

    return auto_scaling_name


def get_dynamodb_tag(client, sys_id):
    """Get dynamodb name by TAG"""

    response_list_tables = client.list_tables()

    table_name_list = []

    for laco_table_name in response_list_tables['TableNames']:
        table_name_list.append(laco_table_name)

    for name in table_name_list:
        response_describe_table = client.describe_table(
            TableName=name)

        response = client.list_tags_of_resource(
            ResourceArn=response_describe_table['Table']['TableArn'],
        )

        for laco_tag in response['Tags']:
            if laco_tag.get('Key') == 'SYS_ID' and laco_tag.get('Value') == sys_id:
                output = name

    return output


def get_ecs_tag(client, sys_id):
    """Get cluster by TAG"""

    ecs_list = []
    response_list_ecs_f = client.list_clusters()

    for laco_cluster_arns in response_list_ecs_f['clusterArns']:
        ecs_list.append(laco_cluster_arns)

        response = client.list_tags_for_resource(
            resourceArn=laco_cluster_arns
        )

        for laco_tag in response['tags']:
            if laco_tag.get('key') == 'SYS_ID' and laco_tag.get('value') == sys_id:
                output = str(laco_cluster_arns)
                cluster_ecs_name = output.split("/")[1]

    return cluster_ecs_name


def get_s3_tag(client, sys_id):
    """Get s3 bucket by TAG"""

    s3_list_name = []

    s3_response = client.list_buckets()
    for laco_s3 in s3_response['Buckets']:
        s3_list_name.append(laco_s3['Name'])

    for laco_tags in s3_list_name:
        try:
            response = client.get_bucket_tagging(
                Bucket=laco_tags
            )
            if response:
                for i in response['TagSet']:
                    if i.get('Key') == 'SYS_ID' and i.get('Value') == sys_id:
                        output = laco_tags
            break
        except ClientError as error:
            if not error:
                continue

    return output


def get_cloudfront_tag(client, sys_id):
    """Get cloufront id by TAG"""

    list_distributions = []

    v_list_distr = client.list_distributions()
    for i in v_list_distr['DistributionList']['Items']:
        list_distributions.append({"ID": i['Id'], "ARN": i['ARN']})

    for laco_tags in list_distributions:
        try:
            response = client.list_tags_for_resource(
                Resource=laco_tags.get('ARN')
            )

            if response:
                for i in response['Tags']['Items']:
                    if i.get('Key') == 'SYS_ID' and i.get('Value') == sys_id:
                        output = laco_tags.get('ID')
            break
        except ClientError as error:
            if not error:
                continue

    return output


def get_elbv2s(client):
    """Get all LBS"""

    lbs = client.describe_load_balancers()
    arns = []
    for load_balancer in lbs['LoadBalancers']:
        arns.append([load_balancer['LoadBalancerArn'], load_balancer['Type']])
    return arns


def get_elbv2_tag(client, sys_id):
    """Get the right Load balancer by sys_id"""

    arns = get_elbv2s(client)

    for arn in arns:
        tags = client.describe_tags(
            ResourceArns=[
                arn[0],
            ])
        regex = fr'{sys_id}'
        check_arn = re.findall(regex, json.dumps(tags))
        if check_arn:
            arn_lb = arn[0].split(':loadbalancer')[1]
            arn_lb = arn_lb[1:]
            return arn_lb, arn[1]

    return ""


def get_workspace_tag(client, sys_id):
    """Get the Workspace ID by sys_id"""

    workspaces = client.describe_workspaces()
    workspaces_list = []
    for workspace in workspaces['Workspaces']:
        workspaces_list.append([workspace['WorkspaceId'],
                                workspace['DirectoryId']])

    for workspace_id in workspaces_list:
        tags = client.describe_tags(
            ResourceId=workspace_id[0])
        regex = fr'{sys_id}'
        check_id = re.findall(regex, json.dumps(tags))
        if check_id:
            return workspace_id

    return ""


def get_tag_nat_gateway(client, sys_id):
    """Function to collect the 'NatGatewayId' from Nat Gateway"""

    response = client.describe_nat_gateways()

    for tags in response['NatGateways']:
        for sysid in tags['Tags']:
            if sysid.get('Key') == 'SYS_ID' and sysid.get('Value') == sys_id:
                output = tags['NatGatewayId']

    return output


def get_tag_ebs(client, sys_id):
    """Function to collect the 'ResourceId' from an Instance EC2 of EBS"""

    response = client.describe_tags()

    for sysid in response['Tags']:
        if sysid.get('Key') == 'SYS_ID' and sysid.get('Value') == sys_id:
            output = sysid['ResourceId']

    return output


def get_tag_route53(client, sys_id):
    """Function to collect the 'HostedZoneId' from Route53"""

    is_truncated = True
    marker = None
    while is_truncated:
        response = client.list_hosted_zones() if marker is None \
            else client.list_hosted_zones(Marker=marker)

        is_truncated = response['IsTruncated']
        marker = response['NextMarker'] if 'NextMarker' in response else None

        for obj in response['HostedZones']:
            hosted_zone = obj['Id'].split("/")[2]
            response2 = client.list_tags_for_resource(
                ResourceType="hostedzone",
                ResourceId=hosted_zone
            )
            for tags in response2['ResourceTagSet']['Tags']:
                if tags['Key'] == "SYS_ID" and tags['Value'] == sys_id:
                    return hosted_zone


def get_id_cache_cluster(client, sys_id):
    """Function to collect the 'CacheClusterId' for Cache Clusters"""

    response = client.describe_cache_clusters()
    resource_caches = []

    for cache_parameter in response['CacheClusters']:
        resource_caches.append({
            "ARN": cache_parameter['ARN'],
            "cache_cluster_id": cache_parameter['CacheClusterId']
        })

    for cache in resource_caches:
        cache_cluster_id = cache['cache_cluster_id']
        tags = client.list_tags_for_resource(
            ResourceName=cache['ARN']
        )

        if 'TagList' in tags:
            for tag in tags['TagList']:
                if tag['Key'].lower() == 'sys_id' and tag['Value'] == sys_id:
                    return cache_cluster_id
    return None


def get_tag_efs(client, sys_id):
    """Function to collect the 'FileSystemId' from EFS"""
    is_truncated = True
    marker = None

    while is_truncated:
        response = client.describe_file_systems() if marker is None \
            else client.describe_file_systems(Marker=marker)

        is_truncated = 'Marker' in response
        marker = response['Marker'] if is_truncated else None

        for file_system in response['FileSystems']:
            tags_filter = filter(
                lambda tag: tag.get('Key') == 'SYS_ID',
                file_system['Tags']
            )
            sys_id_tag = next(iter(list(tags_filter)), None)
            assert sys_id_tag is not None
            if sys_id_tag.get('Value') == sys_id:
                return file_system['FileSystemId']


def get_web_acl_name(client, sys_id):
    """Function to collect the name from Web ACL"""
    wafv2_list = []
    response_list = client.list_web_acls(
        Scope='REGIONAL'
    )

    for resource_arns in response_list['WebACLs']:
        wafv2_list.append(resource_arns)

        wafv2_tags = client.list_tags_for_resource(
            ResourceARN=resource_arns['ARN']
        )

        for wafv2_tag in wafv2_tags['TagInfoForResource']['TagList']:
            if wafv2_tag.get('Key').lower() == 'sys_id' and wafv2_tag.get('Value') == sys_id:
                output = str(resource_arns)
                wafv2 = output.split("/")[2]
                return wafv2

    return None


def get_gateway_id(client, sys_id):
    """Function to collect the 'GatewayName' and 'GatewayId' from Storage Gateway"""
    is_truncated = True
    marker = None
    while is_truncated:
        response = client.list_gateways() if marker is None \
            else client.list_gateways(Marker=marker)

        is_truncated = 'Marker' in response
        marker = response['Marker'] if is_truncated else None

        for gateway in response['Gateways']:
            tags = client.list_tags_for_resource(
                ResourceARN=gateway['GatewayARN']
            )['Tags']

            tags_filter = filter(
                lambda tag: tag.get('Key').upper() == 'SYS_ID',
                tags
            )
            sys_id_tag = next(iter(list(tags_filter)), None)
            assert sys_id_tag is not None
            if sys_id_tag.get('Value') == sys_id:
                return gateway['GatewayName'], [gateway['GatewayId']]
    return None, None


def get_tag_shield(client, sys_id):
    """Function to collect the name from Shield Advanced"""
    shield_list = []
    response_list = client.list_protections()

    for resource_arns in response_list['Protections']:
        shield_list.append(resource_arns)

        shield_tags = client.list_tags_for_resource(
            ResourceARN=resource_arns['ProtectionArn']
        )

        for shield_tag in shield_tags['Tags']:
            if shield_tag.get('Key').upper() == 'SYS_ID' and shield_tag.get('Value') == sys_id:
                return resource_arns['ResourceArn']

    return None


def get_tag_cognito_idp(client, sys_id):
    """Function to collect the user pool id from the user pools"""
    is_truncated = True
    next_token = None

    while is_truncated:
        response = client.list_user_pools(MaxResults=60) if next_token is None \
            else client.list_user_pools(NextToken=next_token, MaxResults=60)

        is_truncated = 'NextToken' in response
        next_token = response['NextToken'] if is_truncated else None

        for user in response['UserPools']:
            user_id = user['Id']
            user_pool = client.describe_user_pool(
                UserPoolId=user_id
            )
            user_pool = user_pool['UserPool']
            if 'UserPoolTags' not in user_pool:
                continue

            list_tags = dict((k.lower(), v)
                             for k, v in user_pool['UserPoolTags'].items())

            if list_tags['sys_id'] != sys_id:
                continue
            return user_id


def get_kms_tag(client, sys_id):
    """Function to collect the 'KeyId' from KMS"""

    is_truncated = True
    marker = None

    while is_truncated:
        response = client.list_keys() if marker is None else client.list_keys(Marker=marker)
        is_truncated = response['Truncated']
        marker = response['NextMarker'] if 'NextMarker' in response else None
        for kms_key in response['Keys']:
            tags = client.list_resource_tags(
                KeyId=kms_key['KeyId']
            )
            # https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/kms.html#KMS.Client.list_resource_tags
            for dict_tags in tags['Tags']:
                if dict_tags['TagKey'].lower() == 'sys_id' and dict_tags['TagValue'] == sys_id:
                    return kms_key['KeyId']

def get_directconnect_tag(client, sys_id):
    """Function to collect the Connection ID"""
    response = client.describe_connections()

    for connection in response['connections']:
        tags = connection['tags']
        for tag in tags:
            if all(part in tag['key'].upper() for part in ['SYS', 'ID']):
                if tag['value'] == sys_id:
                    return connection['connectionId']

    return None



def get_tag_redshift(client, sys_id):
    """Function to collect ClusterIdentifier from Redshift"""

    is_truncated = True
    marker = None

    while is_truncated:
        clusters_description = client.describe_clusters() if marker is None \
            else client.describe_clusters(Marker=marker)
        is_truncated = 'Marker' in clusters_description
        marker = clusters_description['Marker'] if 'Marker' in clusters_description else None

        for cluster in clusters_description['Clusters']:
            tags = cluster['Tags'] if 'Tags' in cluster else [] or []
            sys_id_tag = next(filter(
                lambda tag: all(part in tag['Key'].lower()
                                for part in ['sys', 'id']),
                tags
            ), {'Key': 'sys_id', 'Value': None})
            if sys_id == sys_id_tag['Value']:
                return cluster['ClusterIdentifier']


def get_dms_id(client, sys_id):
    """Function to collect the 'FileSystemId' from EFS"""
    is_truncated = True
    marker = None

    while is_truncated:
        response = client.describe_replication_instances() if marker is None \
            else client.describe_replication_instances(Marker=marker)

        is_truncated = 'Marker' in response
        marker = response['Marker'] if is_truncated else None

        for replication_instances in response['ReplicationInstances']:
            tags = client.list_tags_for_resource(
                ResourceArn=replication_instances["ReplicationInstanceArn"]
            )['TagList']
            tags_filter = filter(
                lambda tag: tag.get('Key').upper() == 'SYS_ID',
                tags
            )
            sys_id_tag = next(iter(list(tags_filter)), None)
            assert sys_id_tag is not None
            if sys_id_tag.get('Value') == sys_id:
                resource_id = replication_instances['ReplicationInstanceArn'].split("rep:")[
                    1]
                instance_identifier = replication_instances['ReplicationInstanceIdentifier']
                instance_class = replication_instances['ReplicationInstanceClass']
                return [resource_id], [instance_identifier], [instance_class]



def get_db_cluster_identifier(client, sys_id):
    """Function to collect the 'FileSystemId' from EFS"""
    is_truncated = True
    marker = None

    while is_truncated:
        response = client.describe_db_clusters() if marker is None \
            else client.describe_db_clusters(Marker=marker)

        is_truncated = 'Marker' in response
        marker = response['Marker'] if is_truncated else None

        for db_cluster in response['DBClusters']:
            tags = client.list_tags_for_resource(  # daqui pra baixo igual
                ResourceName=db_cluster['DBClusterArn']
            )

            for tag in tags['TagList']:
                if tag['Key'].upper() == 'SYS_ID' and tag['Value'] == sys_id:
                    return db_cluster['DBClusterIdentifier']


if __name__ == '__main__':
    print("Favor utilizar outro script para chamar esse.")
