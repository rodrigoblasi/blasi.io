#!/usr/bin/python3

"""This script collects metrics from aws KMS."""

import argparse
import datetime
import aws_client
import aws_errors
import aws_tags
import aws_base


def parse_arguments():
    """Arguments function"""

    parser = argparse.ArgumentParser(
        description='AWS Metrics Zabbix discovery script')
    parser.add_argument("--client-name", dest="client_name",
                        help="Represents the name of the client inserted in zabbix macro",
                        required=True, type=str)
    parser.add_argument("--metric-name", dest="metric_name",
                        help="Availabes metrics: ['SecondsUntilKeyMaterialExpiration']",
                        required=True, type=str)
    parser.add_argument("--sys-id", dest="sys_id",
                        help="AWS sys id that is located in tags.",
                        required=True, type=str)
    parser.add_argument("--statistic", dest="statistic",
                        default=None,
                        help="AWS agregation availables: ['Minimum']",
                        required=False, type=str)
    args = parser.parse_args()

    return args


def kms_handler(login, metric_name, key_id, statistic=None):
    """Function to collect the kms metrics"""

    metric_opts = {
        'Id': 'ksm',
        'MetricStat': {
            'Metric': {
                'Namespace': 'AWS/KMS',
                'MetricName': metric_name,
                'Dimensions': [
                    {
                        "Name": "KeyId",
                        "Value": key_id
                    }]
            },
            'Period': 300,
            'Stat': statistic if statistic is not None else "Minimum",
        }
    }

    now = datetime.datetime.now()
    response = login.get_metric_data(
        MetricDataQueries=[metric_opts],
        StartTime=(now - datetime.timedelta(seconds=7200)).timestamp(),
        EndTime=now.timestamp()
    )

    return response


def main():
    """Main code"""

    try:
        # KMS only works if region is set to us-east-1
        # https://docs.aws.amazon.com/kms/latest/developerguide/overview.html
        args = parse_arguments()

        args.client_name = aws_base.extract_client_name(args.client_name)
        login_cloudwatch = aws_client.login_aws('us-east-1', args.client_name)
        kms_client = aws_client.login_aws('us-east-1', args.client_name, 'kms')
        kms_key_id = aws_tags.get_kms_tag(kms_client, args.sys_id)

        assert kms_key_id is not None, "KMS Key not found"

        call_metrics = kms_handler(
            login_cloudwatch, args.metric_name, kms_key_id)
        metric = aws_base.get_metric(call_metrics)
        print(metric)

    except:
        aws_errors.throws('kms')


if __name__ == '__main__':
    main()
