#!/usr/bin/python3

"""This script collects metrics from aws rds."""

import argparse
import datetime
import aws_client
import aws_tags
import aws_errors
import aws_base

def parse_arguments():
    """Arguments function"""

    parser = argparse.ArgumentParser(
        description='AWS Metrics Zabbix discovery script')
    parser.add_argument("--region", dest="region",
                        help="AWS region.",
                        required=True, type=str)
    parser.add_argument("--client-name", dest="client_name",
                        help="Represents the name of the client inserted in zabbix macro",
                        required=True, type=str)
    parser.add_argument("--metric-name", dest="metric_name",
                        help="Availabes metrics: ['ActiveConnectionCount',\
                            'ConnectionAttemptCount','ConnectionEstablishedCount',\
                            'PacketsDropCount']",
                        required=True, type=str)
    parser.add_argument("--sys-id", dest="sys_id",
                        help="AWS sys id that is located in tags.",
                        required=True, type=str)
    parser.add_argument("--statistic", dest="statistic",
                        help="AWS agregation availables: ['Maximum', 'Sum']",
                        required=True, type=str)
    args = parser.parse_args()

    return args

def natgw_handler(login,metric_name,natgatewayid,statistic):
    """Function to collect the rds metrics"""

    response = login.get_metric_data(
    MetricDataQueries=[
    {
        'Id': 'natgw',
        'MetricStat': {
        'Metric': {
            'Namespace': 'AWS/NATGateway',
            'MetricName': metric_name,
            'Dimensions': [
                    {
                        "Name": "NatGatewayId",
                        "Value": natgatewayid
                    }]
        },
        'Period': 600,
        'Stat': statistic,
        }
    }
    ],
    StartTime=(datetime.datetime.now() - datetime.timedelta(seconds=300)).timestamp(),
    EndTime=datetime.datetime.now().timestamp()
    )

    return response

def get_metric(output_metric):
    """Parsed the output to get the metric"""

    return round(output_metric['MetricDataResults'][0]['Values'][0])

def main():
    """Main code"""

    try:
        args = parse_arguments()

        args.client_name = aws_base.extract_client_name(args.client_name)
        login = aws_client.login_aws(args.region,args.client_name)
        login_natgw = aws_client.login_aws(args.region, args.client_name, 'ec2')
        output_natgatewayid = aws_tags.get_tag_nat_gateway(login_natgw, args.sys_id)
        call_metrics = natgw_handler(login, args.metric_name, output_natgatewayid, args.statistic)
        round_output_metric = get_metric(call_metrics)

        print(round_output_metric)

    except:
        aws_errors.throws('nat-gateway')

if __name__ == '__main__':
    main()
