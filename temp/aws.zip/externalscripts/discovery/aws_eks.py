#!/usr/bin/python3

"""This script collects metrics from aws eks."""

import argparse
import datetime
import aws_client
import aws_tags
import aws_errors
import aws_base

def parse_arguments():
    """Arguments function"""

    parser = argparse.ArgumentParser(
        description='AWS Metrics Zabbix discovery script')
    parser.add_argument("--region", dest="region",
                        help="AWS region.",
                        required=True, type=str)
    parser.add_argument("--client-name", dest="client_name",
                        help="Represents the name of the client inserted in zabbix macro",
                        required=True, type=str)
    parser.add_argument("--metric-name", dest="metric_name",
                        help="AWS Metric Name for EKS. Accepted metrics: \
                            ['cluster_failed_node_count','cluster_node_count',\
                            'node_cpu_usage_total','node_cpu_utilization','node_memory_reserved_capacity',\
                            'node_memory_utilization','node_number_of_running_pods','node_number_of_running_containers',\
                            'pod_cpu_utilization','pod_memory_utilization'] ",
                        required=True, type=str)
    parser.add_argument("--sys-id", dest="sys_id",
                        help="AWS EKS TAG SysID.",
                        required=True, type=str)
    parser.add_argument("--node-name", dest="node_name",
                        help="AWS EKS node name.",
                        required=False, type=str)
    parser.add_argument("--instance-id", dest="instance_id",
                        help="AWS EKS instance ID.",
                        required=False, type=str)
    parser.add_argument("--pod-name", dest="pod_name",
                        help="AWS EKS instance ID.",
                        required=False, type=str)
    parser.add_argument("--namespace", dest="namespace",
                        help="AWS EKS instance ID.",
                        required=False, type=str)
    parser.add_argument("--statistic", dest="statistic",
                        help="AWS agregation type: 'Average', 'Maximum', 'Minimum'",
                        required=True, type=str)
    args = parser.parse_args()

    return args

def check_dimensions(args, cluster_name):
    """Function to construct the dimensions."""

    dimensions_array = ['cluster_name','node_name',\
        'instance_id','pod_name','namespace']
    dict_dimensions = {'cluster_name': 'ClusterName',\
        'node_name':'NodeName', 'instance_id': 'InstanceId',\
            'pod_name': 'PodName', 'namespace': 'Namespace'}
    dict_arguments = {'cluster_name': cluster_name,\
            'node_name': args.node_name, 'instance_id': args.instance_id,\
            'pod_name': args.pod_name, 'namespace': args.namespace}
    dimensions_query = []

    for dimension in dimensions_array:
        if dict_arguments.get(dimension):
            result = {'Name': dict_dimensions.get(dimension),\
                    'Value': dict_arguments.get(dimension)}
            dimensions_query.append(result)

    return dimensions_query

def eks_handler(login,metric_name,stat,dimension):
    """Function to collect the eks metrics"""

    response = login.get_metric_data(
    MetricDataQueries=[
    {
        'Id': 'insights',
        'MetricStat': {
        'Metric': {
            'Namespace': 'ContainerInsights',
            'MetricName': metric_name,
            'Dimensions': dimension
        },
        'Period': 600,
        'Stat': stat,
        }
    }
    ],
    StartTime=(datetime.datetime.now() - datetime.timedelta(seconds=300)).timestamp(),
    EndTime=datetime.datetime.now().timestamp()
    )

    return response

def get_value(outout):
    """Parsed the output to get the metric"""

    return round(outout['MetricDataResults'][0]['Values'][0])

def main():
    """Main code"""

    try:
        args = parse_arguments()
        args.client_name = aws_base.extract_client_name(args.client_name)
        login = aws_client.login_aws(args.region,args.client_name)
        login_eks = aws_client.login_aws(args.region,args.client_name,'eks')
        cluster_name = aws_tags.get_tag_eks(login_eks, args.sys_id)

        dimension = check_dimensions(args, cluster_name)
        output_metric  = eks_handler(login,args.metric_name,args.statistic,dimension)
        output_metric = get_value(output_metric)

        print(output_metric)
    except:
        aws_errors.throws('eks')

if __name__ == '__main__':
    main()
