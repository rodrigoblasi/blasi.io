#!/usr/bin/python3

"""Workspaces metrics"""

import datetime
import argparse
import aws_client
import aws_tags
import aws_errors
import aws_base

def parse_arguments():
    """Arguments function"""

    parser = argparse.ArgumentParser(
        description='AWS Metrics Zabbix discovery script')
    parser.add_argument("--region", dest="region",
                        help="AWS region.",
                        required=True, type=str)
    parser.add_argument("--client-name", dest="client_name",
                        help="Represents the name of the client inserted in zabbix macro",
                        required=True, type=str)
    parser.add_argument("--sys-id", dest="sys_id",
                        help="AWS SYSID TAG that is located in Workspace",
                        required=True, type=str)
    parser.add_argument("--metric-name", dest="metric_name",
                    help="Avaible AWS metric name for Workspace - DirectoryId: ['Available'\
                        'Unhealthy', 'ConnectionAttempt','ConnectionSuccess','ConnectionFailure', \
                        'SessionLaunchTime','InSessionLatency','SessionDisconnect', \
                        'UserConnected','Maintenance','Stopped']\
                        WorkspaceId: ['Available','Unhealthy','Stopped',\
                        'UserConnected','Maintenance']",
                    required=True, type=str)
    parser.add_argument("--dimension", dest="dimension",
                    help="Avaible AWS dimensions - 'DirectoryId','WorkspaceId'",
                    required=True, type=str)
    parser.add_argument("--statistic", dest="statistic",
                        help="AWS agregation availables: ['Average', 'Maximum', 'Minimum', \
                        'Sum','SampleCount']",
                        required=True, type=str)
    args = parser.parse_args()

    return args

def workspace_handler(login_cloudwatch,metric_name,workspace,statistic,dimension):
    """Function to collect the aurora cluster metrics"""

    response = login_cloudwatch.get_metric_data(
    MetricDataQueries=[
    {
        'Id': 'workspace',
        'MetricStat': {
        'Metric': {
            'Namespace': 'AWS/WorkSpaces',
            'MetricName': metric_name,
            'Dimensions': [
                    {
                        "Name": dimension,
                        "Value": workspace
                    }]
        },
        'Period': 600,
        'Stat': statistic,
        }
    }
    ],
    StartTime=(datetime.datetime.now() - datetime.timedelta(seconds=600)).timestamp(),
    EndTime=datetime.datetime.now().timestamp()
    )
    return response

def get_value(workspace_metrics):
    """Parsed the output to get the metric"""
    return round(workspace_metrics['MetricDataResults'][0]['Values'][0])

def main():
    """Main code"""

    try:
        args = parse_arguments()

        args.client_name = aws_base.extract_client_name(args.client_name)
        client = aws_client.login_aws(args.region,args.client_name,'workspaces')
        login_cloudwatch = aws_client.login_aws(args.region,args.client_name)

        workspace_data = aws_tags.get_workspace_tag(client,args.sys_id)

        if args.dimension == 'WorkspaceId':
            workspace = workspace_data[0]
        if args.dimension == 'DirectoryId':
            workspace = workspace_data[1]

        workspace_metric = workspace_handler(
            login_cloudwatch,
            args.metric_name,
            workspace,
            args.statistic,
            args.dimension
        )

        output_metric = get_value(workspace_metric)

        print(output_metric)

    except:
        aws_errors.throws('workspace')

if __name__ == '__main__':
    main()
