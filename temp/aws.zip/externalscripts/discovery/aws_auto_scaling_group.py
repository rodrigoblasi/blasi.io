#!/usr/bin/python3

"""This script collects metrics from AWS Auto Scaling Groups and instances."""

import argparse
import datetime
import aws_client
import aws_errors
import aws_base

def parse_arguments():
    """Arguments function"""

    parser = argparse.ArgumentParser(
        description='AWS Metrics Zabbix discovery script')
    parser.add_argument("--region", dest="region",
                        help="AWS region.",
                        required=True, type=str)
    parser.add_argument("--client-name", dest="client_name",
                        help="Represents the name of the client inserted in zabbix macro",
                        required=True, type=str)
    parser.add_argument("--metric-name", dest="metric_name",
                        help="AWS Metric Name for Auto Scaling Group. Accepted metrics: \
                            [groups: {'GroupTotalInstances','GroupPendingInstances',\
                            'GroupTerminatingInstances'}, instances:{'CPUUtilization',\
                            StatusCheckFailed'}] ",
                            required=True, type=str)
    parser.add_argument("--auto-scaling-group", dest="auto_scaling_group",
                        help="AWS Auto Scaling Group Name.",
                        required=False, type=str)
    parser.add_argument("--instance-id", dest="instance_id",
                        help="AWS Instance ID that is in auto scaling group.",
                        required=False, type=str)
    parser.add_argument("--statistic", dest="statistic",
                        help="AWS agregation type: 'Average', 'Maximum', 'Minimum'",
                        required=True, type=str)
    args = parser.parse_args()

    if args.auto_scaling_group is None and args.instance_id is None:
        parser.error("error: the following arguments are required:\
         --auto-scaling-group or --instance-id")

    return args

def handle_metric(args):
    """Function that organizes the Metric field."""

    metric_type = 'auto_scaling_group'
    if args.instance_id:
        metric_type = 'instance_id'

    dict_dimension = {
        'instance_id': {
            'Namespace': 'AWS/EC2',
            'MetricName': args.metric_name,
            'Dimensions': [{
                'Name': 'InstanceId',
                'Value': args.instance_id
            }]
        },
        'auto_scaling_group': {
            'Namespace': 'AWS/AutoScaling',
            'MetricName': args.metric_name,
            'Dimensions': [{
                'Name': 'AutoScalingGroupName',
                'Value': args.auto_scaling_group
            }]
        }
    }
    metric = dict_dimension.get(metric_type)
    return metric

def auto_scaling_handler(login,metric,statistic):
    """Function to collect the vpn_s2s metrics"""

    response = login.get_metric_data(
    MetricDataQueries=[
    {
        'Id': 'id',
        'MetricStat': {
        'Metric': metric,
        'Period': 600,
        'Stat': statistic,
        }
    }
    ],
    StartTime=(datetime.datetime.now() - datetime.timedelta(seconds=600)).timestamp(),
    EndTime=datetime.datetime.now().timestamp()
    )

    return response

def get_metric(output):
    """Parsed the output to get the metric"""

    return round(output['MetricDataResults'][0]['Values'][0])

def main():
    """Main code"""

    try:
        args = parse_arguments()
        args.client_name = aws_base.extract_client_name(args.client_name)
        login = aws_client.login_aws(args.region,args.client_name)
        metric = handle_metric(args)
        output_metric = auto_scaling_handler(login,metric,args.statistic)
        output_metric = get_metric(output_metric)
        print(output_metric)
    except:
        aws_errors.throws('auto-scaling-group')

if __name__ == '__main__':
    main()
