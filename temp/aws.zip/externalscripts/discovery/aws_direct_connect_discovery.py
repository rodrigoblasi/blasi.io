#!/usr/bin/python3

"""This script collects metrics from aws vpn site to site."""

import argparse
import aws_client
import aws_tags
import aws_errors
import aws_base
import aws_discovery

possible_dimensions = {
    "optical_lane_number": "OpticalLaneNumber",
    "virtual_interface_id": "VirtualInterfaceId"
}

def parse_arguments():
    """Arguments function"""

    parser = argparse.ArgumentParser(
        description='AWS Metrics Zabbix discovery script')
    parser.add_argument("--region", dest="region",
                        help="AWS region.",
                        required=True, type=str)
    parser.add_argument("--client-name", dest="client_name",
                        help="Represents the name of the client inserted in zabbix macro",
                        required=True, type=str)
    parser.add_argument("--sys-id", dest="sys_id",
                        help="TAG SYSID",
                        required=True, type=str)
    parser.add_argument("--dimensions", dest="dimensions",
                        help="Dimension list, separated by a + sign. Possible dimensions: [" +
                        ", ".join(possible_dimensions.keys()) + "]",
                        required=True, type=str)
    args = parser.parse_args()

    return args

def main():
    """Main code"""

    try:
        args = parse_arguments()
        args.client_name = aws_base.extract_client_name(args.client_name)
        direct_connect = aws_client.login_aws(
            args.region,
            args.client_name,
            'directconnect'
        )

        identifier = aws_tags.get_directconnect_tag(direct_connect, args.sys_id)
        assert identifier is not None, "Connection ID not found."

        dimensions = aws_discovery.get_dimensions(
            args,
            "AWS/DX",
            [{"Name": "ConnectionId", "Value": identifier}],
            possible_dimensions
        )

        print(dimensions)

    except:
        aws_errors.throws('direct-connect')

if __name__ == '__main__':
    main()
