#!/usr/bin/python3

"""This script collects metrics from aws Storage Gateway."""

import argparse
import datetime
import aws_client
import aws_tags
import aws_errors
import aws_base


def parse_arguments():
    """Arguments function"""

    parser = argparse.ArgumentParser(
        description='AWS Metrics Zabbix discovery script')
    parser.add_argument("--client-name", dest="client_name",
                        help="Represents the name of the client inserted in zabbix macro",
                        required=True, type=str)
    parser.add_argument("--metric-name", dest="metric_name",
                        help="Availabes metrics: [ " +
                        ", ".join([
                            "CacheHitPercent",
                            "CacheUsed",
                            "MemTotalBytes",
                            "MemUsedBytes",
                            "QueuedWrites",
                            "UserCpuPercent"
                        ]) +
                        " ]",
                        required=True, type=str)
    parser.add_argument("--sys-id", dest="sys_id",
                        help="AWS sys id that is located in tags.",
                        required=True, type=str)
    parser.add_argument("--statistic", dest="statistic",
                        default=None,
                        help="AWS agregation availables: ['Count', 'Average']",
                        required=False, type=str)
    parser.add_argument("--region", dest="region",
                        help="AWS region.",
                        required=True, type=str)
    parser.add_argument("--share-id", dest="share_id",
                        help="Dimensions ShareId.",
                        required=False, type=str)
    parser.add_argument("--gateway-id", dest="gateway_id",
                        help="Dimensions GatewayId.",
                        required=False, type=str)
    args = parser.parse_args()

    return args


def storage_gateway_handler(login, metric_name, gateway_name, statistic, args):
    """Function to collect the storage gateway metrics"""
    dimensions = []

    if args.gateway_id is not None:
        dimensions.append({
            "Name": "GatewayId",
            "Value": args.gateway_id})

    if args.share_id is not None:
        dimensions.append({
            "Name": "ShareId",
            "Value": args.share_id})
    else:
        dimensions.append({
            "Name": "GatewayName",
            "Value": gateway_name})

    metric_opts = {
        'Id': 'storage_gateway',
        'MetricStat': {
            'Metric': {
                'Namespace': 'AWS/StorageGateway',
                'MetricName': metric_name,
            },
            'Period': 300,
            'Stat': statistic if statistic is not None else "Average",
        }
    }

    assert len(dimensions) != 0, "dimensions Not Found"

    metric_opts['MetricStat']['Metric']['Dimensions'] = dimensions

    now = datetime.datetime.now()
    response = login.get_metric_data(
        MetricDataQueries=[metric_opts],
        StartTime=(now - datetime.timedelta(seconds=7200)).timestamp(),
        EndTime=now.timestamp()
    )

    return response


def main():
    """Main code"""

    try:
        args = parse_arguments()

        args.client_name = aws_base.extract_client_name(args.client_name)
        login = aws_client.login_aws(args.region, args.client_name)
        login_storage_gateway = aws_client.login_aws(
            args.region,
            args.client_name,
            'storagegateway')

        gateway_name, _ = aws_tags.get_gateway_id(
            login_storage_gateway, args.sys_id)

        call_metrics = storage_gateway_handler(
            login,
            args.metric_name,
            gateway_name,
            args.statistic,
            args
        )

        metric = aws_base.get_metric(call_metrics)

        print(metric)
    except:
        aws_errors.throws('storage-gateway')


if __name__ == '__main__':
    main()
