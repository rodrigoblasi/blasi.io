#!/usr/bin/python3

"""This script collects the instances from auto scaling group."""

import argparse
import json
import aws_client
import aws_tags
import aws_errors
import aws_base

def parse_arguments():
    """Arguments function"""

    parser = argparse.ArgumentParser(
        description='AWS Metrics Zabbix discovery script')
    parser.add_argument("--region", dest="region",
                        help="AWS region.",
                        required=True, type=str)
    parser.add_argument("--client-name", dest="client_name",
                        help="Represents the name of the client inserted in zabbix macro",
                        required=True, type=str)
    parser.add_argument("--sys-id", dest="sys_id",
                        help="TAG SYSID",
                        required=True, type=str)
    parser.add_argument("--kind", dest="kind",
                        help="Discovery type based in the metric. Available: ['group','instance']",
                        required=True, type=str)
    args = parser.parse_args()

    return args

def get_auto_scaling_group(login,auto_scaling_name):
    """Function that collects the auto scaling group"""

    auto_scaling_groups = login.describe_auto_scaling_groups(
        AutoScalingGroupNames=[
            auto_scaling_name,
        ]
    )

    return auto_scaling_groups

def get_instance_id(auto_scaling_groups,auto_scaling_name):
    """Function that collects the Instance Id's from auto scaling group"""

    instances_ids = []
    for auto_scaling_group in auto_scaling_groups['AutoScalingGroups']:
        if auto_scaling_group['AutoScalingGroupName'] == auto_scaling_name:
            for instance in auto_scaling_group['Instances']:
                instances_ids.append(instance['InstanceId'])

    return instances_ids


def get_discovery_instance(auto_scaling_name,instances_ids):
    """Function that structures the instance output for zabbix"""

    dict_output = {}
    dict_output['data'] = []
    for instance_id in instances_ids:
        dict_output['data'].append(
            {
                "{#AUTOSCALINGGROUPNAME}":auto_scaling_name,
                "{#INSTANCEID}":instance_id
            }
        )
    dict_output = json.dumps(dict_output)
    return dict_output

def get_discovery_group(auto_scaling_name):
    """Function that structures the group name output for zabbix"""

    dict_output = {}
    dict_output['data'] = [{"{#AUTOSCALINGGROUPNAME}":auto_scaling_name}]
    dict_output = json.dumps(dict_output)
    return dict_output

def main():
    """Main code"""

    try:
        args = parse_arguments()
        args.client_name = aws_base.extract_client_name(args.client_name)
        login = aws_client.login_aws(args.region,args.client_name,'autoscaling')

        auto_scaling_name = aws_tags.get_auto_scaling_tag(login, args.sys_id)
        auto_scaling_groups = get_auto_scaling_group(login,auto_scaling_name)
        instances_ids = get_instance_id(auto_scaling_groups,auto_scaling_name)

        if args.kind == 'instance':
            discovery_output = get_discovery_instance(auto_scaling_name,instances_ids)
        if args.kind == 'group':
            discovery_output = get_discovery_group(auto_scaling_name)

        print(discovery_output)
    except:
        aws_errors.throws('auto-scaling-group')

if __name__ == '__main__':
    main()
