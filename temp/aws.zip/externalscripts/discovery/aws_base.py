#!/usr/bin/python3

"""This script contains commonly used functions """


def get_metric(output_metric):
    """Parsed the output to get the metric"""

    assert "MetricDataResults" in output_metric, "Metric results error"
    results = output_metric['MetricDataResults']
    assert isinstance(results, list), "Metric results error"
    assert len(results) > 0, "Metric results not found"
    assert "Values" in results[0], "Metric values error"
    values = results[0]['Values']
    assert isinstance(values, list), "Metric values error"
    assert len(values) > 0, "Metric value not found"

    return round(values[0]) if isinstance(values[0], float) else values[0]


def extract_client_name(client_name):
    """Get the value from client_name variable and return only the client name"""

    client_name = client_name.split(".")
    return client_name[0].lower()


if __name__ == '__main__':
    print("Favor utilizar outro script para chamar esse.")
