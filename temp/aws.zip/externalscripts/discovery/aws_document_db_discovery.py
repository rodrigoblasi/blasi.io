#!/usr/bin/python3

"""This script has the function to discover UserPoolClient, IdentityProvider."""

import argparse
import json
import aws_client
import aws_errors
import aws_tags
import aws_base


def parse_arguments():
    """Arguments function"""

    parser = argparse.ArgumentParser(
        description='AWS Metrics Zabbix discovery script')
    parser.add_argument("--region", dest="region",
                        help="AWS region.",
                        required=True, type=str)
    parser.add_argument("--client-name", dest="client_name",
                        help="Represents the name of the client inserted in zabbix macro",
                        required=True, type=str)
    parser.add_argument("--sys-id", dest="sys_id",
                        help="AWS sys id that is located in tags.",
                        required=True, type=str)
    parser.add_argument("--kind", dest="kind",
                        help="Types available: DBInstanceIdentifier or Role",
                        required=True, type=str)
    args = parser.parse_args()

    return args


def get_db_instance_identifier(client, db_cluster_identifier):
    """Function to collect the 'DBInstanceIdentifier' from DocumentDB"""
    is_truncated = True
    marker = None
    db_instances = []

    while is_truncated:
        response = client.describe_db_instances(
            Filters=[{'Name': 'db-cluster-id',
                      'Values': [db_cluster_identifier]}]
        ) if marker is None \
            else client.describe_db_instances(
                Marker=marker,
                Filters=[{'Name': 'db-cluster-id',
                          'Values': [db_cluster_identifier]}]
        )

        is_truncated = 'Marker' in response
        marker = response['Marker'] if is_truncated else None

        for db_instance in response['DBInstances']:
            db_instances.append(db_instance['DBInstanceIdentifier'])
    return db_instances


def get_role():
    """
    url: https://docs.aws.amazon.com/documentdb/latest/developerguide/cloud_watch.html
    Amazon DocumentDB Dimensions
    """
    return ['WRITER', 'READER']


def main():
    """Main code"""

    try:
        args = parse_arguments()
        assert args.kind in ('DBInstanceIdentifier', 'Role'), \
            "Invalid kind"

        args.client_name = aws_base.extract_client_name(args.client_name)

        login_doc_db = \
            aws_client.login_aws(args.region, args.client_name, 'docdb')

        db_cluster_identifier = aws_tags.get_db_cluster_identifier(
            login_doc_db, args.sys_id)

        discovery_dict = {}

        if args.kind == 'DBInstanceIdentifier':
            discovery_dict["{#DBINSTANCEIDENTIFIER}"] = \
                get_db_instance_identifier(login_doc_db, db_cluster_identifier)

        if args.kind == 'Role':
            discovery_dict["{#ROLE}"] = get_role()

        arg_list = [{}]
        keys = list(discovery_dict.keys())
        while keys != []:
            key = keys.pop(0)

            new_arg_list = []
            for arg in arg_list:
                for value in discovery_dict[key]:
                    new_arg = arg.copy()
                    new_arg[key] = value
                    new_arg_list.append(new_arg)

            arg_list = new_arg_list

        discovery = json.dumps({"data": arg_list})
        print(discovery)
    except:
        aws_errors.throws("document-db")


if __name__ == '__main__':
    main()
