#!/usr/bin/python3

"""This script has the function to discovery the NodeGroups, InstanceID and NodeName."""

import argparse
import json
import aws_client
import aws_tags
import aws_errors
import aws_base

def parse_arguments():
    """Arguments function"""

    parser = argparse.ArgumentParser(
        description='AWS Metrics Zabbix discovery script')
    parser.add_argument("--region", dest="region",
                        help="AWS region.",
                        required=True, type=str)
    parser.add_argument("--sys-id", dest="sys_id",
                        help="TAG SYSID EKS.",
                        required=True, type=str)
    parser.add_argument("--kind", dest="kind",
                        help="Types availables: node_names or pods",
                        required=True, type=str)
    args = parser.parse_args()

    return args

def get_cluster_name(region,sys_id,client_name):
    """Function to get cluster name"""

    login_eks = aws_client.login_aws(region,client_name,'eks')

    cluster_name = aws_tags.get_tag_eks(login_eks,sys_id)
    return cluster_name

def gathering_nodes(login,cluster_name):
    """Function to colect the existem nodes of cluster"""

    dict_output = {}
    output = []

    paginator = login.get_paginator('list_metrics')
    for response in paginator.paginate(
        Dimensions=[{'Name': 'ClusterName', 'Value': cluster_name}],
        MetricName='node_cpu_utilization',
        Namespace='ContainerInsights'):
        for i in response['Metrics']:
            if i['Dimensions'][0]['Name'] == 'InstanceId':
                output.append({"{#CLUSTERNAME}":i['Dimensions'][2]['Value'], \
                "{#NODENAME}":i['Dimensions'][1]['Value'],\
                "{#INSTANCEID}":i['Dimensions'][0]['Value']})

    dict_output['data'] = output
    dict_output = json.dumps(dict_output)

    return dict_output

def gathering_pods(login,cluster_name):
    """Function to colect the existem pods of cluster"""

    dict_output_pod = {}
    output_pod = []

    paginator = login.get_paginator('list_metrics')
    for response in paginator.paginate(
        Dimensions=[{'Name': 'ClusterName', 'Value': cluster_name}],
        MetricName='pod_cpu_utilization',
        Namespace='ContainerInsights'):
        for i in response['Metrics']:
            if i['Dimensions'][0]['Name'] == 'PodName':
                output_pod.append({"{#CLUSTERNAME}":i['Dimensions'][1]['Value'], \
                "{#NAMESPACE}":i['Dimensions'][2]['Value'],\
                "{#PODNAME}":i['Dimensions'][0]['Value']})

    dict_output_pod['data'] = output_pod
    dict_output_pod = json.dumps(dict_output_pod)

    return dict_output_pod

def main():
    """Main code"""

    try:
        args = parse_arguments()
        args.client_name = aws_base.extract_client_name(args.client_name)
        login = aws_client.login_aws(args.region,args.client_name)

        cluster_name = get_cluster_name(args.region,args.sys_id,args.client_name)

        if args.kind == "node_names":
            discovery_output = gathering_nodes(login,cluster_name)
        if args.kind == "pods":
            discovery_output = gathering_pods(login,cluster_name)

        print(discovery_output)

    except:
        aws_errors.throws('eks')

if __name__ == '__main__':
    main()
