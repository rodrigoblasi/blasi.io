#!/usr/bin/python3

"""This script has the function to discover UserPoolClient, IdentityProvider."""

import argparse
import json
import aws_client
import aws_tags
import aws_errors
import aws_base


def parse_arguments():
    """Arguments function"""

    parser = argparse.ArgumentParser(
        description='AWS Metrics Zabbix discovery script')
    parser.add_argument("--region", dest="region",
                        help="AWS region.",
                        required=True, type=str)
    parser.add_argument("--client-name", dest="client_name",
                        help="Represents the name of the client inserted in zabbix macro",
                        required=True, type=str)
    parser.add_argument("--sys-id", dest="sys_id",
                        help="AWS sys id that is located in tags.",
                        required=True, type=str)
    parser.add_argument("--kind", dest="kind",
                        help="Types available: UserPoolClient or UserPoolClient+IdentityProvider",
                        required=True, type=str)
    args = parser.parse_args()

    return args


def get_identity_providers(login, user_pool_id):
    """
    get_paginator creates an iterator that will paginate through responses from
    CognitoIdentityProvider.Client.list_identity_providers()
    """

    provider_ids = []
    paginator = login.get_paginator('list_identity_providers')
    for response in paginator.paginate(
            UserPoolId=user_pool_id):
        provider_ids.extend(response['Providers'])
    return provider_ids


def get_user_pool_clients(login, user_pool_id):
    """
    get_paginator creates an iterator that will paginate through responses from
    CognitoIdentityProvider.Client.list_user_pool_clients()
    """

    login_client_ids = []
    paginator = login.get_paginator('list_user_pool_clients')
    for response in paginator.paginate(UserPoolId=user_pool_id):
        login_client_ids.extend(response['UserPoolClients'])

    return login_client_ids


def main():
    """Main code"""

    try:
        args = parse_arguments()
        assert args.kind in ('UserPoolClient', 'UserPoolClient+IdentityProvider'), \
            "Invalid kind"

        args.client_name = aws_base.extract_client_name(args.client_name)

        login_cognito_idp = \
            aws_client.login_aws(args.region, args.client_name, 'cognito-idp')

        user_pool = \
            aws_tags.get_tag_cognito_idp(login_cognito_idp, args.sys_id)

        assert user_pool is not None, "User pool not found."

        discovery_dict = {}
        discovery_dict["{#USER-POOL-CLIENT}"] = \
            get_user_pool_clients(login_cognito_idp, user_pool)

        assert len(discovery_dict["{#USER-POOL-CLIENT}"]) > 0, \
            "No user pool client found"

        if args.kind == 'UserPoolClient+IdentityProvider':
            discovery_dict["{#IDENTITY-PROVIDER}"] = \
                get_identity_providers(login_cognito_idp, user_pool)

            assert len(discovery_dict["{#IDENTITY-PROVIDER}"]) > 0, \
                "No identity provider found"

        # Merge all the values in each argument into a single list
        arg_list = [{}]
        keys = list(discovery_dict.keys())
        while keys != []:
            key = keys.pop(0)

            new_arg_list = []
            for arg in arg_list:
                for value in discovery_dict[key]:
                    new_arg = arg.copy()
                    new_arg[key] = value
                    new_arg_list.append(new_arg)

            arg_list = new_arg_list

        discovery = json.dumps({"data": arg_list})
        print(discovery)
    except:
        aws_errors.throws("cognito")


if __name__ == '__main__':
    main()
