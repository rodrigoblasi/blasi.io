#!/usr/bin/python3

"""This script collects CloudWatch's metrics dimensions from Amazon Redshift"""

import argparse
import aws_client
import aws_tags
import aws_errors
import aws_base
import aws_discovery

possible_dimensions = {
    "node_id": "NodeID",
    "latency": "latency",
    "wlmid": "wlmid",
    "stage": "stage",
    "service_class": "service class",
    "queue_name": "QueueName",
    "query_priority": "QueryPriority",
    "database_name": "DatabaseName",
    "schema_name": "SchemaName"
}


def parse_arguments():
    """Arguments function"""

    parser = argparse.ArgumentParser(
        description='Amazon Redshift Metrics discovery script for Zabbix')
    parser.add_argument("--region", dest="region",
                        help="AWS region.",
                        required=True, type=str)
    parser.add_argument("--client-name", dest="client_name",
                        help="The name of the client got in zabbix macro " +
                        "(<CLIENT>.<HOSTNAME>)",
                        required=True, type=str)
    parser.add_argument("--sys-id", dest="sys_id",
                        help="Equinix's SYS ID, located in the component's tags",
                        required=True, type=str)
    parser.add_argument("--dimensions", dest="dimensions",
                        help="Dimension list, separated by a + sign. Possible dimensions: [" +
                        ", ".join(possible_dimensions.keys()) + "]",
                        required=True, type=str)
    args = parser.parse_args()

    return args


def main():
    """Main code"""

    try:
        args = parse_arguments()
        args.client_name = aws_base.extract_client_name(args.client_name)
        # Get identifier dimension
        redshift = aws_client.login_aws(
            args.region,
            args.client_name,
            'redshift'
        )
        identifier = aws_tags.get_tag_redshift(redshift, args.sys_id)
        assert identifier is not None, "Cluster Identifier not found"

        dimensions = aws_discovery.get_dimensions(
            args,
            "AWS/Redshift",
            [{'Name': 'ClusterIdentifier', 'Value': identifier}],
            possible_dimensions
        )

        print(dimensions)
    except:
        aws_errors.throws('redshift')


if __name__ == '__main__':
    main()
