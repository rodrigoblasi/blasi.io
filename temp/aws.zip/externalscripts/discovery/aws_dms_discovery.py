#!/usr/bin/python3

"""
This script has the function to discover
ReplicationInstanceExternalResourceId,
ReplicationTaskIdentifier,
ReplicationInstanceIdentifier and
InstanceClass.
"""

import argparse
import json
import aws_client
import aws_tags
import aws_errors
import aws_base


def parse_arguments():
    """Arguments function"""

    parser = argparse.ArgumentParser(
        description='AWS Metrics Zabbix discovery script')
    parser.add_argument("--region", dest="region",
                        help="AWS region.",
                        required=True, type=str)
    parser.add_argument("--client-name", dest="client_name",
                        help="Represents the name of the client inserted in zabbix macro",
                        required=True, type=str)
    parser.add_argument("--sys-id", dest="sys_id",
                        help="AWS sys id that is located in tags.",
                        required=True, type=str)
    parser.add_argument("--kind", dest="kind",
                        help="Types available: [" +
                        "ResourceId, " +
                        "InstanceIdentifier, " +
                        "InstanceClass, " +
                        "InstanceIdentifier+TaskIdentifier" +
                        "]",
                        required=True, type=str)
    args = parser.parse_args()

    return args


def get_task_identifier(login):
    """Function to collect the 'ReplicationTaskIdentifier' from DMS"""
    is_truncated = True
    marker = None
    tasks = []

    while is_truncated:
        response = login.describe_replication_tasks() if marker is None \
            else login.describe_replication_tasks(Marker=marker)

        is_truncated = 'Marker' in response
        marker = response['Marker'] if is_truncated else None

        for replication_task in response['ReplicationTasks']:
            tasks.append(replication_task['ReplicationTaskIdentifier'])
            tasks.append(
                replication_task['ReplicationTaskArn'].split(":task:")[1]
            )
    return tasks


def main():
    """Main code"""

    try:
        args = parse_arguments()
        assert args.kind in (
            'ResourceId',
            'InstanceIdentifier',
            'InstanceClass',
            'InstanceIdentifier+TaskIdentifier'), "Invalid kind"

        args.client_name = aws_base.extract_client_name(args.client_name)

        login_dms = aws_client.login_aws(
            args.region,
            args.client_name,
            'dms'
        )

        discovery_dict = {}

        if args.kind == 'ResourceId':
            discovery_dict["{#RESOURCEID}"], _, _ = \
                aws_tags.get_dms_id(login_dms, args.sys_id)

        if args.kind == 'InstanceIdentifier':
            _, discovery_dict["{#INSTANCEIDENTIFIER}"], _ = \
                aws_tags.get_dms_id(login_dms, args.sys_id)

        if args.kind == 'InstanceClass':
            _, _, discovery_dict["{#INSTANCECLASS}"] = \
                aws_tags.get_dms_id(login_dms, args.sys_id)

        if args.kind == 'InstanceIdentifier+TaskIdentifier':
            _, discovery_dict["{#INSTANCEIDENTIFIER}"], _ = \
                aws_tags.get_dms_id(login_dms, args.sys_id)

            discovery_dict["{#TASKIDENTIFIER}"] = \
                get_task_identifier(login_dms)

        # Merge all the values in each argument into a single list
        arg_list = [{}]
        keys = list(discovery_dict.keys())
        while keys != []:
            key = keys.pop(0)

            new_arg_list = []
            for arg in arg_list:
                for value in discovery_dict[key]:
                    new_arg = arg.copy()
                    new_arg[key] = value
                    new_arg_list.append(new_arg)

            arg_list = new_arg_list

        discovery = json.dumps({"data": arg_list})
        print(discovery)
    except:
        aws_errors.throws("dms")


if __name__ == '__main__':
    main()
