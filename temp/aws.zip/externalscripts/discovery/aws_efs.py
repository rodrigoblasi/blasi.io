#!/usr/bin/python3

"""This script collects metrics from aws efs."""

import argparse
import datetime
import aws_client
import aws_tags
import aws_errors
import aws_base


def parse_arguments():
    """Arguments function"""

    parser = argparse.ArgumentParser(
        description='AWS Metrics Zabbix discovery script')
    parser.add_argument("--region", dest="region",
                        help="AWS region.",
                        required=True, type=str)
    parser.add_argument("--client-name", dest="client_name",
                        help="Represents the name of the client inserted in zabbix macro",
                        required=True, type=str)
    parser.add_argument("--metric-name", dest="metric_name",
                        help="Availabes metrics: ['ClientConnections',\
                            'PercentIOLimit','TotalIOBytes']",
                        required=True, type=str)
    parser.add_argument("--sys-id", dest="sys_id",
                        help="AWS sys id that is located in tags.",
                        required=True, type=str)
    parser.add_argument("--statistic", dest="statistic",
                        help="AWS agregation availables: ['Average', 'Sum', \
                                'Maximum', 'Minimum', 'DataSamples']",
                        required=True, type=str)
    args = parser.parse_args()

    return args


def route_handler(login, metric_name, file_system_id, statistic):
    """Function to collect the efs metrics"""

    now = datetime.datetime.now()
    response = login.get_metric_data(
        MetricDataQueries=[
            {
                'Id': 'efs',
                'MetricStat': {
                    'Metric': {
                        'Namespace': 'AWS/EFS',
                        'MetricName': metric_name,
                        'Dimensions': [
                            {
                                "Name": "FileSystemId",
                                "Value": file_system_id
                            }]
                    },
                    'Period': 300,
                    'Stat': statistic,
                }
            }
        ],
        StartTime=(now - datetime.timedelta(seconds=7200)).timestamp(),
        EndTime=now.timestamp()
    )

    return response


def main():
    """Main code"""

    try:
        args = parse_arguments()

        args.client_name = aws_base.extract_client_name(args.client_name)
        login = aws_client.login_aws(args.region, args.client_name)
        login_efs = aws_client.login_aws(
            args.region,
            args.client_name,
            'efs'
        )

        file_system = aws_tags.get_tag_efs(login_efs, args.sys_id)

        assert file_system is not None, "File System ID Not Found"

        call_metrics = route_handler(
            login,
            args.metric_name,
            file_system,
            args.statistic
        )

        metric = aws_base.get_metric(call_metrics)

        print(metric)
    except:
        aws_errors.throws('efs')


if __name__ == '__main__':
    main()
