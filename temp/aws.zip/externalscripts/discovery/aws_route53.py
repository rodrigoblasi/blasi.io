#!/usr/bin/python3

"""This script collects metrics from aws route53."""

import argparse
import datetime
import aws_client
import aws_tags
import aws_errors
import aws_base


def parse_arguments():
    """Arguments function"""

    parser = argparse.ArgumentParser(
        description='AWS Metrics Zabbix discovery script')
    parser.add_argument("--client-name", dest="client_name",
                        help="Represents the name of the client inserted in zabbix macro",
                        required=True, type=str)
    parser.add_argument("--metric-name", dest="metric_name",
                        help="Availabes metrics: ['DNSQueries',\
                            'DNSSECInternalFailure','DNSSECKeySigningKeysNeedingAction',\
                            'DNSSECKeySigningKeyMaxNeedingActionAge', 'DNSSECKeySigningKeyAge']",
                        required=True, type=str)
    parser.add_argument("--sys-id", dest="sys_id",
                        help="AWS sys id that is located in tags.",
                        required=True, type=str)
    parser.add_argument("--statistic", dest="statistic",
                        default=None,
                        help="AWS agregation availables: ['SampleCount', 'Sum']",
                        required=False, type=str)
    args = parser.parse_args()

    return args


def route_handler(login, metric_name, hosted_zone_id, statistic):
    """Function to collect the route53 metrics"""

    metric_opts = {
        'Id': 'route53',
        'MetricStat': {
            'Metric': {
                'Namespace': 'AWS/Route53',
                'MetricName': metric_name,
                'Dimensions': [
                    {
                        "Name": "HostedZoneId",
                        "Value": hosted_zone_id
                    }]
            },
            'Period': 300,
            'Stat': statistic if statistic is not None else "Average",
        }
    }

    now = datetime.datetime.now()
    response = login.get_metric_data(
        MetricDataQueries=[metric_opts],
        StartTime=(now - datetime.timedelta(seconds=7200)).timestamp(),
        EndTime=now.timestamp()
    )

    return response


def main():
    """Main code"""

    try:
        # Route53 only works if region is set to us-east-1
        # https://docs.aws.amazon.com/Route53/latest/DeveloperGuide/hosted-zone-public-viewing-query-metrics.html
        args = parse_arguments()

        args.client_name = aws_base.extract_client_name(args.client_name)
        login = aws_client.login_aws('us-east-1', args.client_name)
        login_route = aws_client.login_aws(
            'us-east-1',
            args.client_name,
            'route53')

        hosted_zone = aws_tags.get_tag_route53(login_route, args.sys_id)

        assert hosted_zone is not None, "Hosted Zone ID Not Found"

        call_metrics = route_handler(
            login,
            args.metric_name,
            hosted_zone,
            args.statistic
        )

        metric = aws_base.get_metric(call_metrics)

        print(metric)
    except:
        aws_errors.throws('route53')


if __name__ == '__main__':
    main()
