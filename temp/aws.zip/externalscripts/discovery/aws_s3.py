#!/usr/bin/python3

"""Step to discovery DBClusterIdentifier and DBInstanceIdentifier CI from AWS REST API"""

import datetime
import argparse
import aws_client
import aws_tags
import aws_errors
import aws_base

def parse_arguments():
    """Arguments function"""

    parser = argparse.ArgumentParser(
        description='AWS Metrics Zabbix discovery script')
    parser.add_argument("--region", dest="region",
                        help="AWS region.",
                        required=True, type=str)
    parser.add_argument("--client-name", dest="client_name",
                        help="Represents the name of the client inserted in zabbix macro",
                        required=True, type=str)
    parser.add_argument("--sys-id", dest="sys_id",
                        help="TAG SYSID",
                        required=True, type=str)
    parser.add_argument("--metric-name", dest="metric_name",
                    help="Avaible AWS metric name for Bucket S3 - 'BucketSizeBytes'",
                    required=True, type=str)
    parser.add_argument("--statistic", dest="statistic",
                        help="AWS agregation availables: ['Average']",
                        required=True, type=str)
    args = parser.parse_args()

    return args

def storage_class_s3(client, s3_bucket_name):
    """Collects the metric for s3"""

    response = client.list_metrics(
        Namespace='AWS/S3',
        MetricName='BucketSizeBytes',
        Dimensions=[
            {
                'Name': 'StorageType'
            },
        ]
    )

    for i in response['Metrics']:
        if i['Dimensions'][1].get('Value') == s3_bucket_name:
            output_stor_class = i['Dimensions'][0].get('Value')

    return output_stor_class

def s3_handler(login_cloudwatch,metric_name,s3_bucket_name,statistic, storage_class_name):
    """Function to collect the aurora cluster metrics"""

    now = datetime.datetime.now()
    response = login_cloudwatch.get_metric_data(
    MetricDataQueries=[
    {
        'Id': 's3',
        'MetricStat': {
        'Metric': {
            'Namespace': "AWS/S3",
            'MetricName': metric_name,
            'Dimensions': [
                    {
                        "Name": "BucketName",
                        "Value": s3_bucket_name
                    },
                    {
                        "Name": "StorageType",
                        "Value": storage_class_name
                    }
                    ]
        },
        'Period': 3600,
        'Stat': statistic,
        }
    }
    ],
    StartTime=(now-datetime.timedelta(days=1)).isoformat(),
    EndTime=now.isoformat()

    )
    return response

def get_value(s3_metrics):
    """Parsed the output to get the metric"""
    return round(s3_metrics['MetricDataResults'][0]['Values'][0])

def main():
    """Main code"""

    try:
        arguments = parse_arguments()

        arguments.client_name = aws_base.extract_client_name(arguments.client_name)
        client = aws_client.login_aws(arguments.region,arguments.client_name,'s3')
        login_cloudwatch = aws_client.login_aws(arguments.region,arguments.client_name)

        s3_bucket_name = aws_tags.get_s3_tag(client, arguments.sys_id)
        storage_class_name = storage_class_s3(login_cloudwatch, s3_bucket_name)

        s3_metrics = s3_handler(login_cloudwatch,
                                arguments.metric_name,
                                s3_bucket_name,
                                arguments.statistic,
                                storage_class_name)
        output = get_value(s3_metrics)

        print(output)

    except:
        aws_errors.throws('s3')

if __name__ == '__main__':
    main()
