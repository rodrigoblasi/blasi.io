#!/usr/bin/python3

"""This script collects metrics from Amazon Redshift"""

import argparse
import datetime
import aws_client
import aws_tags
import aws_errors
import aws_base


def parse_arguments():
    """Arguments function"""

    parser = argparse.ArgumentParser(
        description='Amazon Redshift Metrics discovery script for Zabbix')
    parser.add_argument("--region", dest="region",
                        help="AWS region.",
                        required=True, type=str)
    parser.add_argument("--client-name", dest="client_name",
                        help="The name of the client got in zabbix macro " +
                        "(<CLIENT>.<HOSTNAME>)",
                        required=True, type=str)
    parser.add_argument("--metric-name", dest="metric_name",
                        help="Availabes metrics: " + ", ".join([]),
                        required=True, type=str)
    parser.add_argument("--sys-id", dest="sys_id",
                        help="Equinix's SYS ID, located in the component's tags",
                        required=True, type=str)
    parser.add_argument("--statistic", dest="statistic",
                        help="AWS CloudWatch agregation: [" +
                        ", ".join(
                            ['SampleCount', 'Sum', 'Average',
                             'Minimum', 'Maximum']) + "]",
                        required=True, type=str)
    parser.add_argument("--node_id", dest="node_id",
                        help="Identifier for a node of a cluster",
                        required=False, default=None, type=str)
    parser.add_argument("--latency", dest="latency",
                        help="Possible values: [short, medium, long]",
                        required=False, default=None, type=str)
    parser.add_argument("--wlmid", dest="wlmid",
                        help="Identifier for a workload management queue",
                        required=False, default=None, type=str)
    parser.add_argument("--stage", dest="stage",
                        help="Execution stages for a query. Possible values: [" +
                        ", ".join([
                            "QueryPlanning",
                            "QueryWaiting",
                            "QueryExecutingRead",
                            "QueryExecutingInsert",
                            "QueryExecutingDelete",
                            "QueryExecutingUpdate",
                            "QueryExecutingCtas",
                            "QueryExecutingUnload",
                            "QueryExecutingCopy",
                            "QueryCommit"
                        ]) + "]",
                        required=False, default=None, type=str)
    parser.add_argument("--service_class", dest="service_class",
                        help="Identifier for a WLM service class",
                        required=False, default=None, type=str)
    parser.add_argument("--queue_name", dest="queue_name",
                        help="Name of the workload management queue",
                        required=False, default=None, type=str)
    parser.add_argument("--query_priority", dest="query_priority",
                        help="Priority of the query. Possible values: " +
                        "[CRITICAL, HIGHEST, HIGH, NORMAL, LOW, LOWEST]",
                        required=False, default=None, type=str)
    parser.add_argument("--database_name", dest="database_name",
                        help="Name of the database",
                        required=False, default=None, type=str)
    parser.add_argument("--schema_name", dest="schema_name",
                        help="Name of the schema",
                        required=False, default=None, type=str)
    args = parser.parse_args()

    return args


def get_dimensions(cluster_identifier, args):
    """Converts arguments into CloudWatch's dimension list"""

    dimensions = [{"Name": "ClusterIdentifier", "Value": cluster_identifier}]

    if 'node_id' in args and args.node_id is not None:
        dimensions.append({"Name": "NodeID", "Value": args.node_id})

    if 'latency' in args and args.latency is not None:
        dimensions.append({"Name": "latency", "Value": args.latency})

    if 'wlmid' in args and args.wlmid is not None:
        dimensions.append({"Name": "wlmid", "Value": args.wlmid})

    if 'stage' in args and args.stage is not None:
        dimensions.append({"Name": "stage", "Value": args.stage})

    if 'service_class' in args and args.service_class is not None:
        dimensions.append(
            {"Name": "service class", "Value": args.service_class})

    if 'queue_name' in args and args.queue_name is not None:
        dimensions.append({"Name": "QueueName", "Value": args.queue_name})

    if 'query_priority' in args and args.query_priority is not None:
        dimensions.append(
            {"Name": "QueryPriority", "Value": args.query_priority})

    if 'database_name' in args and args.database_name is not None:
        dimensions.append(
            {"Name": "DatabaseName", "Value": args.database_name})

    if 'schema_name' in args and args.schema_name is not None:
        dimensions.append({"Name": "SchemaName", "Value": args.schema_name})

    return dimensions


def cloud_watch_handler(args, dimensions):
    """Function to collect Amazon Redshift CloudWatch's metrics"""
    cloud_watch = aws_client.login_aws(args.region, args.client_name)

    now = datetime.datetime.now()
    response = cloud_watch.get_metric_data(
        MetricDataQueries=[
            {
                'Id': 'redshift',
                'MetricStat': {
                    'Metric': {
                        'Namespace': 'AWS/Redshift',
                        'MetricName': args.metric_name,
                        'Dimensions': dimensions
                    },
                    'Period': 300,
                    'Stat': args.statistic,
                }
            }
        ],
        StartTime=(now - datetime.timedelta(seconds=7200)).timestamp(),
        EndTime=now.timestamp()
    )

    return response


def main():
    """Main code"""

    try:
        args = parse_arguments()
        args.client_name = aws_base.extract_client_name(args.client_name)

        redshift = aws_client.login_aws(
            args.region,
            args.client_name,
            'redshift'
        )

        cluster_identifier = aws_tags.get_tag_redshift(redshift, args.sys_id)
        assert cluster_identifier is not None, "Cluster Identifier not found"

        dimensions = get_dimensions(cluster_identifier, args)
        metric = cloud_watch_handler(args, dimensions)

        metric_value = aws_base.get_metric(metric)

        # Special case, convert Megabytes to Bytes
        if args.metric_name == 'StorageUsed':
            metric_value *= 1048576

        print(metric_value)
    except:
        aws_errors.throws('redshift')


if __name__ == '__main__':
    main()
