#!/usr/bin/python3

"""This script collects metrics from aws eks."""

import argparse
import datetime
import aws_client
import aws_errors
import aws_base

def parse_arguments():
    """Arguments function"""

    parser = argparse.ArgumentParser(
        description='AWS Metrics Zabbix discovery script')
    parser.add_argument("--region", dest="region",
                        help="AWS region.",
                        required=True, type=str)
    parser.add_argument("--client-name", dest="client_name",
                        help="Represents the name of the client inserted in zabbix macro",
                        required=True, type=str)
    parser.add_argument("--metric-name", dest="metric_name",
                        help="AWS Metric Name for EKS. Accepted metrics: \
                            ['TunnelState','TunnelDataIn',\
                            'TunnelDataOut'] ",
                            required=True, type=str)
    parser.add_argument("--tunnel-ip-address", dest="tunnel_ip_address",
                        help="AWS VPN s2s Tunnel IP Address.",
                        required=True, type=str)
    parser.add_argument("--vpn-id", dest="vpn_id",
                        help="AWS VPN s2s VPN ID.",
                        required=True, type=str)
    parser.add_argument("--statistic", dest="statistic",
                        help="AWS agregation type: 'Average', 'Maximum', 'Minimum'",
                        required=True, type=str)
    args = parser.parse_args()

    return args

def check_dimensions(args):
    """Function to construct the dimensions."""

    dimensions_array = ['vpn_id','tunnel_ip_address']
    dict_dimensions = {'vpn_id': 'VpnId',\
        'tunnel_ip_address':'TunnelIpAddress'}
    dict_arguments = {'vpn_id': args.vpn_id,\
            'node_name': args.tunnel_ip_address}
    dimensions_query = []

    for dimension in dimensions_array:
        if dict_arguments.get(dimension):
            result = {'Name': dict_dimensions.get(dimension),\
                    'Value': dict_arguments.get(dimension)}
            dimensions_query.append(result)

    return dimensions_query

def vpn_s2s_handler(login,metric_name,statistic,dimension):
    """Function to collect the vpn_s2s metrics"""

    response = login.get_metric_data(
    MetricDataQueries=[
    {
        'Id': 'id',
        'MetricStat': {
        'Metric': {
            'Namespace': 'AWS/VPN',
            'MetricName': metric_name,
            'Dimensions': dimension
        },
        'Period': 600,
        'Stat': statistic,
        }
    }
    ],
    StartTime=(datetime.datetime.now() - datetime.timedelta(seconds=300)).timestamp(),
    EndTime=datetime.datetime.now().timestamp()
    )

    return response

def get_value_round(output):
    """Parsed the output to get the metric"""

    return round(output['MetricDataResults'][0]['Values'][0])

def main():
    """Main code"""

    try:
        args = parse_arguments()
        args.client_name = aws_base.extract_client_name(args.client_name)
        login = aws_client.login_aws(args.region,args.client_name)

        dimension = check_dimensions(args)
        output_metric  = vpn_s2s_handler(login,args.metric_name,args.statistic,dimension)
        metric_value = get_value_round(output_metric)

        print(metric_value)
    except:
        aws_errors.throws('vpn-s2s')

if __name__ == '__main__':
    main()
