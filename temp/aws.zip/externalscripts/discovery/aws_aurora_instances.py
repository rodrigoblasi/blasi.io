#!/usr/bin/python3

"""Step to discovery DBClusterIdentifier and DBInstanceIdentifier CI from AWS REST API"""

import argparse
import json
import aws_client
import aws_tags
import aws_errors
import aws_base

def parse_arguments():
    """Arguments function"""

    parser = argparse.ArgumentParser(
        description='AWS Metrics Zabbix discovery script')
    parser.add_argument("--region", dest="region",
                        help="AWS region.",
                        required=True, type=str)
    parser.add_argument("--client-name", dest="client_name",
                        help="Represents the name of the client inserted in zabbix macro",
                        required=True, type=str)
    parser.add_argument("--sys-id", dest="sys_id",
                        help="TAG SYSID",
                        required=True, type=str)
    args = parser.parse_args()

    return args


def main():
    """Main code"""

    try:
        arguments = parse_arguments()

        arguments.client_name = aws_base.extract_client_name(arguments.client_name)
        client = aws_client.login_aws(arguments.region,arguments.client_name,'rds')
        response = client.describe_db_clusters(
            DBClusterIdentifier=aws_tags.get_tag_aurora(client, arguments.sys_id)
            )

        # listdbcm = response['DBClusters'][0]['DBClusterMembers']
        poslist = 0
        nodelist = []
        nodedict = {}


        sizelistdbcm = len(response['DBClusters'][0]['DBClusterMembers'])

        while poslist < sizelistdbcm:
            nodelist.append({"{#DBINSTANCE}":response['DBClusters'][0]\
            ['DBClusterMembers'][poslist]['DBInstanceIdentifier']})
            poslist+=1

        nodedict['data']=nodelist

        print(json.dumps(nodedict))
    except:
        aws_errors.throws('aurora')

if __name__ == '__main__':
    main()
