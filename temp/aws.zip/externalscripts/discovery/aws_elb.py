#!/usr/bin/python3

"""Elastic Load Balancer metrics"""

import datetime
import argparse
import aws_client
import aws_tags
import aws_errors
import aws_base


def parse_arguments():
    """Arguments function"""

    parser = argparse.ArgumentParser(
        description='AWS Metrics Zabbix discovery script')
    parser.add_argument("--region", dest="region",
                        help="AWS region.",
                        required=True, type=str)
    parser.add_argument("--client-name", dest="client_name",
                        help="Represents the name of the client inserted in zabbix macro",
                        required=True, type=str)
    parser.add_argument("--sys-id", dest="sys_id",
                        help="AWS SYSID TAG that is located in ELB",
                        required=True, type=str)
    parser.add_argument("--metric-name", dest="metric_name",
                        help="Avaible AWS metric name for ELB - 'RequestCount'\
                        'HealthyHostCount', 'TargetResponseTime'",
                        required=True, type=str)
    parser.add_argument("--statistic", dest="statistic",
                        help="AWS agregation availables: ['Average', 'Maximum', 'Minimum']",
                        required=True, type=str)
    parser.add_argument("--target-group", dest="target_group",
                        default=None,
                        help="Filters the metric data by target group.",
                        required=False, type=str)
    parser.add_argument("--availability-zone", dest="availability_zone",
                        default=None,
                        help="Filters the metric data by Availability Zone.",
                        required=False, type=str)
    args = parser.parse_args()

    return args


def assemble_dimensions(metric_name, arn_lb, args):
    """ function responsible for assemble the dimensions """
    dimensions = [
        {
            "Name": "LoadBalancer",
            "Value": arn_lb.strip()
        }
    ]

    if "UnHealthyHostCount" in metric_name:

        assert args.target_group is not None, "TargetGroup is " \
            "mandatory to UnHealthyHostCount metric"
        dimensions.append(
            {
                "Name": "TargetGroup",
                "Value": args.target_group
            }
        )

        if args.availability_zone is not None:
            dimensions.append(
                {
                    "Name": "AvailabilityZone",
                    "Value": args.availability_zone
                }
            )

    return dimensions


def elbv2_handler(login_cloudwatch, args, arn_lb, namespace):
    """Function to collect the aurora cluster metrics"""
    metric_name = args.metric_name
    statistic = args.statistic

    dimensions = assemble_dimensions(metric_name, arn_lb, args)

    response = login_cloudwatch.get_metric_data(
        MetricDataQueries=[
            {
                'Id': 'elbv2',
                'MetricStat': {
                    'Metric': {
                        'Namespace': namespace,
                        'MetricName': metric_name,
                        'Dimensions': dimensions
                    },
                    'Period': 600,
                    'Stat': statistic,
                }
            }
        ],
        StartTime=(datetime.datetime.now() -
                   datetime.timedelta(seconds=300)).timestamp(),
        EndTime=datetime.datetime.now().timestamp()
    )
    return response


def get_elb_namespace(namespace_type):
    """Get LB type and return with namespace"""

    elb_dict = {
        "application": "AWS/ApplicationELB",
        "network": "AWS/NetworkELB",
        "gateway": "AWS/ELB"
    }

    return elb_dict.get(namespace_type)


def get_value(elb_metrics):
    """Parsed the output to get the metric"""
    return round(elb_metrics['MetricDataResults'][0]['Values'][0])


def main():
    """Main code"""

    try:
        args = parse_arguments()

        args.client_name = aws_base.extract_client_name(args.client_name)
        client = aws_client.login_aws(args.region, args.client_name, 'elbv2')
        login_cloudwatch = aws_client.login_aws(args.region, args.client_name)

        arn_lb = aws_tags.get_elbv2_tag(client, args.sys_id)
        elb_type = get_elb_namespace(arn_lb[1])

        elbv2_stat = elbv2_handler(
            login_cloudwatch,
            args,
            arn_lb[0],
            elb_type
        )
        output = get_value(elbv2_stat)

        print(output)

    except:
        aws_errors.throws('elb')


if __name__ == '__main__':
    main()
