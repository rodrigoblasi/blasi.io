#!/usr/bin/python3

"""Generic dimension discovery via cloud_watch"""

import copy
import json
import aws_client


def parse_dimensions(dimensions, possible_dimensions):
    """Parses args.dimension"""

    dimensions = dimensions.split("+")
    assert all(
        dim in possible_dimensions for dim in dimensions), "Invalid dimensions"
    return [possible_dimensions[dim] for dim in dimensions]


def flatten(to_flat):
    """Given a list of lists, returns a flat list of its sub elements"""
    return [item for sublist in to_flat for item in sublist]


def get_all_metrics(args, namespace, initial_filter):
    """Retrieves all metrics from CloudWatch"""
    client = aws_client.login_aws(args.region, args.client_name)

    is_truncated = True
    next_token = None
    metrics = []

    while is_truncated:
        metrics_list = client.list_metrics(
            Namespace=namespace,
            Dimensions=initial_filter
        ) if next_token is None else \
            client.list_metrics(
                Namespace=namespace,
                Dimensions=initial_filter,
                NextToken=next_token
        )

        is_truncated = 'NextToken' in metrics_list
        next_token = metrics_list['NextToken'] if is_truncated else None

        metrics = flatten([metrics, metrics_list['Metrics']])

    return metrics


def get_dimension_list(metrics):
    """Returns a flat list of all Key/Value pair of dimensions"""

    dimensions = list(map(lambda metric: metric['Dimensions'], metrics))
    flat_dimensions = flatten(dimensions)
    return flat_dimensions


def get_key_from_value(dictionary, target):
    """Returns a key from a dict given its value"""
    return next((k for k, v in dictionary.items() if v == target), target)


def parse_zabbix(dimensions, possible_dimensions):
    """Parses all dicts of a dimensions list to comply with Zabbix"""

    new_dimensions = []
    for value in dimensions:
        new_value = {}
        for key in value:
            original_name = get_key_from_value(possible_dimensions, key)
            zabbix_key = original_name.upper().replace("-", "_")
            zabbix_key = f"{{#{zabbix_key}}}"
            new_value[zabbix_key] = value[key]
        new_dimensions.append(new_value)

    return new_dimensions


def get_dimensions(args, namespace, initial_filter, possible_dimensions):
    """Queries and parses a list of dimensions, returning a JSON compliant with Zabix"""

    assert all(arg in args for arg in ['dimensions', 'region', 'client_name']), \
        "Missing required arguments"
    assert isinstance(args.dimensions, str), "Invalid dimensions argument"
    # possible_dimensions is spected to be an dict with the following format:
    # { "dimension_in_script": "dimension in cloudwatch"}
    assert isinstance(possible_dimensions, dict), "Invalid possible dimensions"
    assert all(isinstance(k, str) and isinstance(v, str)
               for k, v in possible_dimensions.items()), "Invalid possible dimensions"

    args.dimensions = parse_dimensions(args.dimensions, possible_dimensions)

    metrics = get_all_metrics(args, namespace, initial_filter)
    dimensions = get_dimension_list(metrics)
    names = list(map(lambda dimension: dimension['Name'], dimensions))
    assert all(dimension in names for dimension in args.dimensions), \
        "Some dimensions are not available"

    values = [{}]
    for dimension in args.dimensions:
        new_values = []
        for value in values:
            curr_dim = [dim for dim in dimensions if dim['Name'] == dimension]
            possible_values = [dim['Value'] for dim in curr_dim]
            possible_values = list(set(possible_values))
            possible_values.sort()
            for possible_value in possible_values:
                new_value = copy.deepcopy(value)
                new_value.update({dimension: possible_value})
                new_values.append(new_value)
        values = new_values

    values = parse_zabbix(values, possible_dimensions)

    return json.dumps(values)


if __name__ == '__main__':
    print("Favor utilizar outro script para chamar esse.")
