#!/usr/bin/python3

"""This script collects metrics from aws Storage Gateway."""

import argparse
import datetime
import aws_client
import aws_tags
import aws_errors
import aws_base


def parse_arguments():
    """Arguments function"""

    parser = argparse.ArgumentParser(
        description='AWS Metrics Zabbix discovery script')
    parser.add_argument("--client-name", dest="client_name",
                        help="Represents the name of the client inserted in zabbix macro",
                        required=True, type=str)
    parser.add_argument("--metric-name", dest="metric_name",
                        help="Availabes metrics: [ " +
                        ", ".join([
                            "CPUUtilization",
                            "VolumeBytesUsed",
                            "FreeableMemory",
                            "FreeLocalStorage",
                            "DatabaseConnections",
                            "VolumeReadIOPS",
                            "VolumeWriteIOPS",
                            "NetworkThroughput",
                            "ReadThroughput",
                            "WriteThroughput",
                            "ReadLatency",
                            "WriteLatency"
                        ]) +
                        " ]",
                        required=True, type=str)
    parser.add_argument("--sys-id", dest="sys_id",
                        help="AWS sys id that is located in tags.",
                        required=True, type=str)
    parser.add_argument("--statistic", dest="statistic",
                        default=None,
                        help="AWS agregation availables: ['Average', 'Sum' ,\
                             'SampleCount', 'Maximum']",
                        required=False, type=str)
    parser.add_argument("--region", dest="region",
                        help="AWS region.",
                        required=True, type=str)
    parser.add_argument("--db-instance-identifier", dest="db_instance_identifier",
                        help="Filters the data that you request for a specific database instance.",
                        required=False, type=str)
    parser.add_argument("--role", dest="role",
                        help="AWS role: ['WRITER', 'READER'].",
                        required=False, type=str)
    args = parser.parse_args()

    return args


def get_dimensions(db_cluster_identifier, args):
    """Converts arguments into CloudWatch's dimension list"""
    dimensions = []
    if args.db_instance_identifier is not None:
        dimensions.append({"Name": "DBInstanceIdentifier",
                          "Value": args.db_instance_identifier})
    else:
        dimensions.append({"Name": "DBClusterIdentifier",
                           "Value": db_cluster_identifier})
        if args.role is not None:
            dimensions.append({"Name": "Role", "Value": args.role})

    return dimensions


def document_db_handler(login, metric_name, statistic, dimension):
    """Function to collect the document db metrics"""

    metric_opts = {
        'Id': 'document_db',
        'MetricStat': {
            'Metric': {
                'Namespace': 'AWS/DocDB',
                'MetricName': metric_name,
                'Dimensions': dimension
            },
            'Period': 3600,
            'Stat': statistic if statistic is not None else "Average",
        }
    }

    now = datetime.datetime.now()
    response = login.get_metric_data(
        MetricDataQueries=[metric_opts],
        StartTime=(now - datetime.timedelta(seconds=7200)).timestamp(),
        EndTime=now.timestamp()
    )

    return response


def main():
    """Main code"""

    try:
        args = parse_arguments()

        args.client_name = aws_base.extract_client_name(args.client_name)
        login = aws_client.login_aws(args.region, args.client_name)
        login_document_db = aws_client.login_aws(
            args.region,
            args.client_name,
            'docdb')

        db_cluster_identifier = aws_tags.get_db_cluster_identifier(
            login_document_db, args.sys_id)

        assert db_cluster_identifier is not None, "db_cluster_identifier Not Found"

        dimension = get_dimensions(db_cluster_identifier, args)

        call_metrics = document_db_handler(
            login,
            args.metric_name,
            args.statistic,
            dimension
        )

        metric = aws_base.get_metric(call_metrics)

        print(metric)
    except:
        aws_errors.throws('document-db')


if __name__ == '__main__':
    main()
