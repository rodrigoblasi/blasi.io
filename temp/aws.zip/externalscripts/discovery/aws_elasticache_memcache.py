#!/usr/bin/python3

"""This script collects metrics from aws elasticache memcache ."""

import argparse
import datetime
import aws_client
import aws_tags
import aws_errors
import aws_base


def parse_arguments():
    """Arguments function"""

    parser = argparse.ArgumentParser(
        description='AWS Metrics Zabbix discovery script')
    parser.add_argument("--client-name", dest="client_name",
                        help="Represents the name of the client inserted in zabbix macro",
                        required=True, type=str)
    parser.add_argument("--metric-name", dest="metric_name",
                        help="Availabes metrics: [" +
                        ", ".join([
                            'CPUUtilization',
                            'SwapUsage',
                            'Evictions',
                            'CurrConnections']) +
                        "]",
                        required=True, type=str)
    parser.add_argument("--sys-id", dest="sys_id",
                        help="AWS sys id that is located in tags.",
                        required=True, type=str)
    parser.add_argument("--statistic", dest="statistic",
                        default=None,
                        help="AWS agregation availables: [" +
                        ", ".join([
                            'Average',
                            'Maximum',
                            'Sum']) +
                        "]",
                        required=False, type=str)
    args = parser.parse_args()

    return args


def elastic_handler(login, metric_name, cache_cluster_id, statistic):
    """Function to collect the elastiCache metrics"""

    metric_opts = {
        'Id': 'elastiCache',
        'MetricStat': {
            'Metric': {
                'Namespace': 'AWS/ElastiCache',
                'MetricName': metric_name,
                'Dimensions': [
                    {
                        "Name": "CacheClusterId",
                        "Value": cache_cluster_id
                    }]
            },
            'Period': 300,
            'Stat': statistic if statistic is not None else "Average",
        }
    }

    now = datetime.datetime.now()
    response = login.get_metric_data(
        MetricDataQueries=[metric_opts],
        StartTime=(now - datetime.timedelta(seconds=7200)).timestamp(),
        EndTime=now.timestamp()
    )

    return response


def main():
    """Main code"""

    try:
        # ElastiCache only works if region is set to us-east-1
        # https://docs.aws.amazon.com/AmazonElastiCache/latest/mem-ug/WhatIs.html
        args = parse_arguments()

        args.client_name = aws_base.extract_client_name(args.client_name)
        login = aws_client.login_aws('us-east-1', args.client_name)
        login_cache_cluster = aws_client.login_aws(
            'us-east-1',
            args.client_name,
            'elasticache')

        cache_cluster_id = aws_tags.get_id_cache_cluster(
            login_cache_cluster, args.sys_id)

        assert cache_cluster_id is not None, "Cache Cluster Id Not Found"
        call_metrics = elastic_handler(
            login,
            args.metric_name,
            cache_cluster_id,
            args.statistic
        )

        metric = aws_base.get_metric(call_metrics)

        print(metric)
    except:
        aws_errors.throws('elasticache-memcache')


if __name__ == '__main__':
    main()
