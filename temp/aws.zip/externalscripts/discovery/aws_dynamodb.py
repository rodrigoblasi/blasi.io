#!/usr/bin/python3

"""Step to discovery DBClusterIdentifier and DBInstanceIdentifier CI from AWS REST API"""

import datetime
import argparse
import aws_client
import aws_tags
import aws_errors
import aws_base

def parse_arguments():
    """Arguments function"""

    parser = argparse.ArgumentParser(
        description='AWS Metrics Zabbix discovery script')
    parser.add_argument("--region", dest="region",
                        help="AWS region.",
                        required=True, type=str)
    parser.add_argument("--client-name", dest="client_name",
                        help="Represents the name of the client inserted in zabbix macro",
                        required=True, type=str)
    parser.add_argument("--sys-id", dest="sys_id",
                        help="TAG SYSID",
                        required=True, type=str)
    parser.add_argument("--metric-name", dest="metric_name",
                    help="Avaible AWS metric name for DynamoDB - 'ProvisionedReadCapacityUnits', \
                            'ProvisionedWriteCapacityUnits', 'ConsumedReadCapacityUnits', \
                            'ConsumedWriteCapacityUnits'",
                    required=True, type=str)
    parser.add_argument("--statistic", dest="statistic",
                        help="AWS agregation availables: ['Average', 'Maximum', 'Minimum']",
                        required=True, type=str)
    args = parser.parse_args()

    return args

def dynamodb_handler(login_cloudwatch,metric_name,table_name,statistic):
    """Function to collect the aurora cluster metrics"""

    response = login_cloudwatch.get_metric_data(
    MetricDataQueries=[
    {
        'Id': 'id',
        'MetricStat': {
        'Metric': {
            'Namespace': "AWS/DynamoDB",
            'MetricName': metric_name,
            'Dimensions': [
                    {
                        "Name": "TableName",
                        "Value": table_name
                    }]
        },
        'Period': 600,
        'Stat': statistic,
        }
    }
    ],
    StartTime=(datetime.datetime.now() - datetime.timedelta(seconds=300)).timestamp(),
    EndTime=datetime.datetime.now().timestamp()
    )

    return response

def get_value(dynamodb_metrics):
    """Parsed the output to get the metric"""
    return round(dynamodb_metrics['MetricDataResults'][0]['Values'][0])

def main():
    """Main code"""

    try:
        arguments = parse_arguments()
        arguments.client_name = aws_base.extract_client_name(arguments.client_name)
        client = aws_client.login_aws(arguments.region,arguments.client_name,'dynamodb')
        login_cloudwatch = aws_client.login_aws(arguments.region,arguments.client_name)

        table_name = aws_tags.get_dynamodb_tag(client, arguments.sys_id)
        dynamodb_metrics = dynamodb_handler(login_cloudwatch,
                                            arguments.metric_name,
                                            table_name,
                                            arguments.statistic)

        output_metric = get_value(dynamodb_metrics)
        print(output_metric)

    except:
        aws_errors.throws('dynamodb')

if __name__ == '__main__':
    main()
