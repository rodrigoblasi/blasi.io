#!/usr/bin/python3

"""This script collects metrics from aws rds."""

import argparse
import datetime
import aws_client
import aws_tags
import aws_errors
import aws_base

def parse_arguments():
    """Arguments function"""

    parser = argparse.ArgumentParser(
        description='AWS Metrics Zabbix discovery script')
    parser.add_argument("--region", dest="region",
                        help="AWS region.",
                        required=True, type=str)
    parser.add_argument("--client-name", dest="client_name",
                        help="Represents the name of the client inserted in zabbix macro",
                        required=True, type=str)
    parser.add_argument("--metric-name", dest="metric_name",
                        help="Availabes metrics: ['CPUUtilization',\
                            'WriteLatency','ReadLatency','FreeStorageSpace',\
                            'FreeableMemory','SwapUsage','DatabaseConnections',\
                            'AllocatedStorage']",
                        required=True, type=str)
    parser.add_argument("--instance-name", dest="instance_name",
                        help="AWS instance name of rds.",
                        required=False, type=str)
    parser.add_argument("--sys-id", dest="sys_id",
                        help="AWS sys id that is located in tags.",
                        required=False, type=str)
    parser.add_argument("--statistic", dest="statistic",
                        help="AWS agregation availables: ['Average', 'Maximum', 'Minimum']",
                        required=True, type=str)
    args = parser.parse_args()

    if args.instance_name is None and args.sys_id is None:
        parser.error("error: the following arguments are required: --sys-id or --instance-name")

    return args

def rds_handler(login,metric_name,instance_name,statistic):
    """Function to collect the rds metrics"""

    response = login.get_metric_data(
    MetricDataQueries=[
    {
        'Id': 'rds',
        'MetricStat': {
        'Metric': {
            'Namespace': 'AWS/RDS',
            'MetricName': metric_name,
            'Dimensions': [
                    {
                        "Name": "DBInstanceIdentifier",
                        "Value": instance_name
                    }]
        },
        'Period': 600,
        'Stat': statistic,
        }
    }
    ],
    StartTime=(datetime.datetime.now() - datetime.timedelta(seconds=300)).timestamp(),
    EndTime=datetime.datetime.now().timestamp()
    )

    return response

def get_allocated_storage(client,instance_name):
    """Function to get the total allocate storage in instance"""

    database = client.describe_db_instances(
            DBInstanceIdentifier=instance_name,
            Marker='string'
        )
    output = database['DBInstances'][0]['AllocatedStorage']
    return output * 1073741824

def get_metric(output_metric):
    """Parsed the output to get the metric"""

    return round(output_metric['MetricDataResults'][0]['Values'][0])

def main():
    """Main code"""

    try:
        args = parse_arguments()

        args.client_name = aws_base.extract_client_name(args.client_name)
        login = aws_client.login_aws(args.region,args.client_name)
        login_rds = aws_client.login_aws(args.region,args.client_name,'rds')
        instance_name = args.instance_name

        if args.sys_id:
            instance_name = aws_tags.get_tag_rds(login_rds,args.sys_id)

        if not args.metric_name == "AllocatedStorage":
            output_metric  = rds_handler(login,args.metric_name,instance_name,args.statistic)
            output_metric = get_metric(output_metric)

            print(output_metric)
            return

        output_metric  = get_allocated_storage(login_rds,instance_name)
        print(output_metric)

    except:
        aws_errors.throws('rds')

if __name__ == '__main__':
    main()
