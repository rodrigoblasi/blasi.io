#!/usr/bin/python3

"""This script collects metrics from aws vpn site to site."""

import argparse
import json
import aws_client
import aws_tags
import aws_errors
import aws_base

def parse_arguments():
    """Arguments function"""

    parser = argparse.ArgumentParser(
        description='AWS Metrics Zabbix discovery script')
    parser.add_argument("--region", dest="region",
                        help="AWS region.",
                        required=True, type=str)
    parser.add_argument("--client-name", dest="client_name",
                        help="Represents the name of the client inserted in zabbix macro",
                        required=True, type=str)
    parser.add_argument("--sys-id", dest="sys_id",
                        help="TAG SYSID",
                        required=True, type=str)
    args = parser.parse_args()

    return args

def get_vpnconnid_tunipaddr(login,sys_id):
    """Function that collects the metrics"""

    tunnel_ip_address_list = []
    tunnel_ip_address_dict = {}

    desc_vpn_conn = login.describe_vpn_connections(
            Filters=[
            {
                'Name': 'vpn-gateway-id',
                'Values': [
                    aws_tags.get_vpngateway_id(login, sys_id),
                ]
            },
        ],
    )

    for laco_vpn_connections in desc_vpn_conn['VpnConnections']:
        for laco_tags in laco_vpn_connections['Tags']:
            if laco_tags.get('Key') == 'SYSID' and laco_tags.get('Value') == sys_id:
                vpn_connection_id = laco_vpn_connections['VpnConnectionId']

                for i in desc_vpn_conn['VpnConnections']:
                    for j in i['VgwTelemetry']:
                        tunnel_ip_address_list.append({"{#VPNCONNECTIONID}":vpn_connection_id,\
                        "{#TUNNELIPADDRESS}":j['OutsideIpAddress']})

    tunnel_ip_address_dict['data']=tunnel_ip_address_list
    output_dict = json.dumps(tunnel_ip_address_dict)

    return output_dict

def main():
    """Main code"""

    try:
        args = parse_arguments()
        args.client_name = aws_base.extract_client_name(args.client_name)
        login = aws_client.login_aws(args.region,args.client_name,'ec2')

        discovery_output = get_vpnconnid_tunipaddr(login,args.sys_id)

        print(discovery_output)

    except:
        aws_errors.throws('vpn-s2s')

if __name__ == '__main__':
    main()
