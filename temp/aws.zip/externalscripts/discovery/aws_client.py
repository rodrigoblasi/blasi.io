#!/usr/bin/python3

"""This script makes the login in aws"""

import configparser
import boto3


def login_aws(region, client_name, namespace='cloudwatch'):
    """Function login in AWS"""

    conf_file_path = f"/usr/lib/zabbix/externalscripts/conf/aws_{client_name}.conf"

    with open(conf_file_path) as conf_file:
        config = configparser.ConfigParser()
        config.read_file(conf_file)

        account_name = config.sections()[0]
        user_value = config.get(account_name, 'key')
        passwd_value = config.get(account_name, 'secret')

        aws_login = boto3.client(namespace,
                                 aws_access_key_id=user_value,
                                 aws_secret_access_key=passwd_value,
                                 region_name=region)

        user_value = ""
        passwd_value = ""

    return aws_login


if __name__ == '__main__':
    print("Favor utilizar outro script para chamar esse.")
