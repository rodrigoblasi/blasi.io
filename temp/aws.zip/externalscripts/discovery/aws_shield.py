#!/usr/bin/python3

"""This script collects metrics from aws shield."""

import argparse
import datetime
import aws_client
import aws_tags
import aws_errors
import aws_base


def parse_arguments():
    """Arguments function"""

    parser = argparse.ArgumentParser(
        description='AWS Metrics Zabbix discovery script')
    parser.add_argument("--client-name", dest="client_name",
                        help="Represents the name of the client inserted in zabbix macro",
                        required=True, type=str)
    parser.add_argument("--metric-name", dest="metric_name",
                        help="Availabes metrics: [ " +
                        ", ".join([
                            "DDoSDetected",
                            "DDoSAttackBitsPerSecond",
                            "DDoSAttackPacketsPerSecond",
                            "DDoSAttackRequestsPerSecond"
                        ]) +
                        " ]",
                        required=True, type=str)
    parser.add_argument("--sys-id", dest="sys_id",
                        help="AWS sys id that is located in tags.",
                        required=True, type=str)
    parser.add_argument("--statistic", dest="statistic",
                        default=None,
                        help="AWS agregation availables: [ " +
                        ", ".join([
                            "SampleCount",
                            "Sum"
                        ]) +
                        " ]",
                        required=False, type=str)
    args = parser.parse_args()

    return args


def shield_handler(login, metric_name, resource_arn, statistic):
    """Function to collect the shield metrics"""

    metric_opts = {
        'Id': 'shield',
        'MetricStat': {
            'Metric': {
                'Namespace': 'AWS/DDoSProtection',
                'MetricName': metric_name,
                'Dimensions': [
                    {
                        "Name": "ResourceArn",
                        "Value": resource_arn
                    }
                ]
            },
            'Period': 300,
            'Stat': statistic if statistic is not None else "Average",
        }
    }

    now = datetime.datetime.now()
    response = login.get_metric_data(
        MetricDataQueries=[metric_opts],
        StartTime=(now - datetime.timedelta(seconds=7200)).timestamp(),
        EndTime=now.timestamp()
    )

    return response


def main():
    """Main code"""

    try:
        # shield only works if region is set to us-east-1
        # https://docs.aws.amazon.com/waf/latest/developerguide/shield-chapter.html
        args = parse_arguments()

        args.client_name = aws_base.extract_client_name(args.client_name)
        login = aws_client.login_aws('us-east-1', args.client_name)
        login_shield = aws_client.login_aws(
            'us-east-1',
            args.client_name,
            'shield')

        resource_arn = aws_tags.get_tag_shield(login_shield, args.sys_id)
        assert resource_arn is not None, "ResourceArn ID Not Found"

        call_metrics = shield_handler(
            login,
            args.metric_name,
            resource_arn,
            args.statistic
        )

        metric = aws_base.get_metric(call_metrics)

        print(metric)
    except:
        aws_errors.throws('shield')


if __name__ == '__main__':
    main()
