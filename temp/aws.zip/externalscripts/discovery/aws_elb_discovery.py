#!/usr/bin/python3

"""This script collects CloudWatch's metrics dimensions from ELB"""

import argparse
import aws_client
import aws_tags
import aws_errors
import aws_base
import aws_discovery

possible_dimensions = {
    "target_group": "TargetGroup",
    "availability_zone": "AvailabilityZone"
}


def parse_arguments():
    """Arguments function"""

    parser = argparse.ArgumentParser(
        description='Amazon ELB Metrics discovery script for Zabbix')
    parser.add_argument("--region", dest="region",
                        help="AWS region.",
                        required=True, type=str)
    parser.add_argument("--client-name", dest="client_name",
                        help="The name of the client got in zabbix macro " +
                        "(<CLIENT>.<NAME>)",
                        required=True, type=str)
    parser.add_argument("--sys-id", dest="sys_id",
                        help="Equinix's SYS ID, located in the component's tags",
                        required=True, type=str)
    parser.add_argument("--dimensions", dest="dimensions",
                        help="Dimension list, separated by a + sign. Possible dimensions: [" +
                        ", ".join(possible_dimensions.keys()) + "]",
                        required=True, type=str)
    args = parser.parse_args()

    return args


def main():
    """Main code"""

    try:
        args = parse_arguments()
        args.client_name = aws_base.extract_client_name(args.client_name)
        # Get identifier dimension
        client_elb = aws_client.login_aws(
            args.region,
            args.client_name,
            'elbv2'
        )
        load_balancer = aws_tags.get_elbv2_tag(client_elb, args.sys_id)
        assert load_balancer is not None, "LoadBalancer not found"

        dimensions = aws_discovery.get_dimensions(
            args,
            "AWS/ApplicationELB",
            [{'Name': 'LoadBalancer', 'Value': load_balancer[0]}],
            possible_dimensions
        )

        print(dimensions)
    except:
        aws_errors.throws('elb')


if __name__ == '__main__':
    main()
