#!/usr/bin/python3

"""This script collects metrics from aws Database Migration Service."""

import argparse
import datetime
import aws_client
import aws_errors
import aws_base


def parse_arguments():
    """Arguments function"""

    parser = argparse.ArgumentParser(
        description='AWS Metrics Zabbix discovery script')
    parser.add_argument("--client-name", dest="client_name",
                        help="Represents the name of the client inserted in zabbix macro",
                        required=True, type=str)
    parser.add_argument("--metric-name", dest="metric_name",
                        help="Availabes metrics: [ " +
                        ", ".join([
                            "CacheHitPercent",
                            "CacheUsed",
                            "Connection Attempt Count",
                            "MemTotalBytes",
                            "MemUsedBytes",
                            "QueuedWrites",
                            "UserCpuPercent"
                        ]) +
                        " ]",
                        required=True, type=str)
    parser.add_argument("--sys-id", dest="sys_id",
                        help="AWS sys id that is located in tags.",
                        required=True, type=str)
    parser.add_argument("--statistic", dest="statistic",
                        default=None,
                        help="AWS agregation availables: ['Count', 'Average']",
                        required=False, type=str)
    parser.add_argument("--region", dest="region",
                        help="AWS region.",
                        required=True, type=str)
    parser.add_argument("--resource-id", dest="resource_id",
                        help="AWS region.",
                        required=False, type=str)
    parser.add_argument("--instance-identifier", dest="instance_identifier",
                        help="AWS region.",
                        required=False, type=str)
    parser.add_argument("--instance-class", dest="instance_class",
                        help="AWS region.",
                        required=False, type=str)
    parser.add_argument("--task-identifier", dest="task_identifier",
                        help="AWS region.",
                        required=False, type=str)

    args = parser.parse_args()

    return args


def dms_handler(login, metric_name, statistic, args):
    """Function to collect the Database Migration Service metrics"""
    dimensions = []

    if args.resource_id is not None:
        dimensions.append({
            "Name": "ReplicationInstanceExternalResourceId",
            "Value": args.resource_id})

    if args.task_identifier is not None:
        dimensions.append({
            "Name": "ReplicationTaskIdentifier",
            "Value": args.task_identifier})

    if args.instance_identifier is not None:
        dimensions.append({
            "Name": "ReplicationInstanceIdentifier",
            "Value": args.instance_identifier})

    if args.instance_class is not None:
        dimensions.append({
            "Name": "InstanceClass",
            "Value": args.instance_class})

    metric_opts = {
        'Id': 'dms',
        'MetricStat': {
            'Metric': {
                'Namespace': 'AWS/DMS',
                'MetricName': metric_name,
            },
            'Period': 300,
            'Stat': statistic if statistic is not None else "Average",
        }
    }

    if len(dimensions) != 0:
        metric_opts['MetricStat']['Metric']['Dimensions'] = dimensions

    now = datetime.datetime.now()
    response = login.get_metric_data(
        MetricDataQueries=[metric_opts],
        StartTime=(now - datetime.timedelta(seconds=7200)).timestamp(),
        EndTime=now.timestamp()
    )

    return response


def main():
    """Main code"""

    try:
        args = parse_arguments()

        args.client_name = aws_base.extract_client_name(args.client_name)
        login = aws_client.login_aws(args.region, args.client_name)

        call_metrics = dms_handler(
            login,
            args.metric_name,
            args.statistic,
            args
        )

        metric = aws_base.get_metric(call_metrics)

        print(metric)
    except:
        aws_errors.throws('dms')


if __name__ == '__main__':
    main()
