#!/usr/bin/python3

"""This script has the function to discover ShareId and GatewayId."""

import argparse
import json
import aws_client
import aws_tags
import aws_errors
import aws_base


def parse_arguments():
    """Arguments function"""

    parser = argparse.ArgumentParser(
        description='AWS Metrics Zabbix discovery script')
    parser.add_argument("--region", dest="region",
                        help="AWS region.",
                        required=True, type=str)
    parser.add_argument("--client-name", dest="client_name",
                        help="Represents the name of the client inserted in zabbix macro",
                        required=True, type=str)
    parser.add_argument("--sys-id", dest="sys_id",
                        help="AWS sys id that is located in tags.",
                        required=True, type=str)
    parser.add_argument("--kind", dest="kind",
                        help="Types available: ShareId or GatewayId",
                        required=True, type=str)
    args = parser.parse_args()

    return args


def get_share_id(client, sys_id):
    """Function to collect the 'FileShareId' from Storage Gateway"""
    is_truncated = True
    marker = None
    while is_truncated:
        response = client.list_file_shares() if marker is None \
            else client.list_file_shares(Marker=marker)

        is_truncated = 'Marker' in response
        marker = response['Marker'] if is_truncated else None

        for file_share in response['FileShareInfoList']:
            tags = client.list_tags_for_resource(
                ResourceARN=file_share['FileShareARN']
            )['Tags']

            tags_filter = filter(
                lambda tag: tag.get('Key').upper() == 'SYS_ID',
                tags
            )
            sys_id_tag = next(iter(list(tags_filter)), None)
            assert sys_id_tag is not None
            if sys_id_tag.get('Value') == sys_id:
                return [file_share['FileShareId']]


def main():
    """Main code"""

    try:
        args = parse_arguments()
        assert args.kind in ('ShareId', 'GatewayId'), "Invalid kind"

        args.client_name = aws_base.extract_client_name(args.client_name)

        login_storage_gateway = aws_client.login_aws(
            args.region,
            args.client_name,
            'storagegateway')

        discovery_dict = {}

        if args.kind == 'GatewayId':
            _, discovery_dict["{#GATEWAYID}"] = aws_tags.get_gateway_id(
                login_storage_gateway,
                args.sys_id
            )
            assert len(discovery_dict["{#GATEWAYID}"]) > 0, \
                "No GatewayId found"

        if args.kind == 'ShareId':
            discovery_dict["{#SHAREID}"] = get_share_id(
                login_storage_gateway,
                args.sys_id
            )
            assert len(discovery_dict["{#SHAREID}"]) > 0, \
                "No ShareId found"

        # Merge all the values in each argument into a single list
        arg_list = [{}]
        keys = list(discovery_dict.keys())
        while keys != []:
            key = keys.pop(0)

            new_arg_list = []
            for arg in arg_list:
                for value in discovery_dict[key]:
                    new_arg = arg.copy()
                    new_arg[key] = value
                    new_arg_list.append(new_arg)

            arg_list = new_arg_list

        discovery = json.dumps({"data": arg_list})
        print(discovery)
    except:
        aws_errors.throws("storage-gateway")


if __name__ == '__main__':
    main()
