#!/usr/bin/python3

"""This script collects metrics from aws cognito."""

import argparse
import datetime
import aws_client
import aws_tags
import aws_errors
import aws_base


def parse_arguments():
    """Arguments function"""

    parser = argparse.ArgumentParser(
        description='AWS Metrics Zabbix discovery script')
    parser.add_argument("--region", dest="region",
                        help="AWS region.",
                        required=True, type=str)
    parser.add_argument("--client-name", dest="client_name",
                        help="Represents the name of the client inserted in zabbix macro",
                        required=True, type=str)
    parser.add_argument("--metric-name", dest="metric_name",
                        help="Availabes metrics: [ " +
                        ", ".join([
                            "SignUpSuccesses",
                            "SignUpThrottles",
                            "SignInSuccesses",
                            "SignInThrottles",
                            "TokenRefreshSuccesses",
                            "TokenRefreshThrottles",
                            "FederationSuccesses",
                            "FederationThrottles"
                        ]) +
                        " ]",
                        required=True, type=str)
    parser.add_argument("--sys-id", dest="sys_id",
                        help="AWS sys id that is located in tags.",
                        required=True, type=str)
    parser.add_argument("--statistic", dest="statistic",
                        default=None,
                        help="AWS agregation availables: [ " +
                        ", ".join([
                            "Average",
                            "Sum",
                            "SampleCount"
                        ]) +
                        " ]",
                        required=False, type=str)
    parser.add_argument("--user-pool-client", dest="user_pool_client",
                        help="Client that have been created for the specified user pool.",
                        required=True, type=str)
    parser.add_argument("--identity-provider", dest="identity_provider",
                        help="Identity provider for a user pool.",
                        required=False, default=None, type=str)
    args = parser.parse_args()

    return args


def cognito_handler(login_cloudwatch, user_pool, args):
    """Function to collect the Cognito metrics"""

    dimensions = []
    dimensions.append({
        "Name": "UserPool",
        "Value": user_pool})
    dimensions.append({
        "Name": "UserPoolClient",
        "Value": args.user_pool_client})
    if args.identity_provider is not None:
        dimensions.append({
            "Name": "IdentityProvider",
            "Value": args.identity_provider})

    metric_opts = {
        'Id': 'cognito',
        'MetricStat': {
            'Metric': {
                'Namespace': 'AWS/Cognito',
                'MetricName': args.metric_name,
                'Dimensions': dimensions
            },
            'Period': 300,
            'Stat': args.statistic if args.statistic is not None else "Average",
        }
    }

    now = datetime.datetime.now()
    response = login_cloudwatch.get_metric_data(
        MetricDataQueries=[metric_opts],
        StartTime=(now - datetime.timedelta(seconds=7200)).timestamp(),
        EndTime=now.timestamp()
    )

    return response


def main():
    """Main code"""

    try:

        args = parse_arguments()

        args.client_name = aws_base.extract_client_name(args.client_name)

        login_cloudwatch = aws_client.login_aws(args.region, args.client_name)
        login_cognito_idp = aws_client.login_aws(
            args.region, args.client_name, 'cognito-idp')

        user_pool = aws_tags.get_tag_cognito_idp(
            login_cognito_idp, args.sys_id)

        assert user_pool is not None, "User pool not found."

        call_metrics = cognito_handler(login_cloudwatch, user_pool, args)

        metric = aws_base.get_metric(call_metrics)

        print(metric)
    except:
        aws_errors.throws('cognito')


if __name__ == '__main__':
    main()
