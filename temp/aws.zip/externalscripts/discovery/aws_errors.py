#!/usr/bin/python3

"""This script contain the error dictionary """

error_dictionary = {
    "rds": -1,
    "eks": -2,
    "aurora": -3,
    "vpn-s2s": -4,
    "auto-scaling-group": -5,
    "dynamodb": -6,
    "ecs": -7,
    "s3": -8,
    "cloudfront": -9,
    "elb": -10,
    "workspace": -11,
    "nat-gateway": -12,
    "ebs": -13,
    "route53": -14,
    "efs": -15,
    "elasticache-memcache": -16,
    "elasticache-for-redis": -17,
    "shield": -18,
    "waf": -19,
    "kms": -20,
    "cognito": -21,
    "storage-gateway": -22,
    "redshift": -23,
    "direct-connect": -24,
    "dms": -25,
    "document-db": -26,
    "aws-client": -101
}


def throws(error_component):
    """Raise error"""

    print(error_dictionary.get(error_component))
    raise SystemExit


if __name__ == '__main__':
    print("Favor utilizar outro script para chamar esse.")
